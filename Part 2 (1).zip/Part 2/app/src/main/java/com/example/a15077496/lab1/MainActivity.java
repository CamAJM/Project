package com.example.a15077496.lab1;

import android.app.FragmentManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.stream.JsonReader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import group.Group;
import user.User;

public class MainActivity extends AppCompatActivity {



    private TabLayout tabLayout;
    private ViewPager viewPager;
    private ViewPagerAdapter adapter;

    // private Switch SwitchButton;
    ArrayList<Integer> all = new ArrayList<>();
    User user;




    public static String sensorServerURL = "http://10.0.2.2:8080/ProjectTesting/";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        StrictMode.ThreadPolicy policy =
                new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);



        Intent intent = getIntent();
        String username = intent.getStringExtra("username");
        String password = intent.getStringExtra("password");




        tabLayout = (TabLayout) findViewById(R.id.tablayout_id);
        viewPager = (ViewPager) findViewById(R.id.viewpager_id);
        adapter = new ViewPagerAdapter(getSupportFragmentManager());

        int index;


        //Add Fragments Here
        Bundle bundle = new Bundle();
        bundle.putString("username", username);
        bundle.putString("password", password);
        FragmentHue fragHue = new FragmentHue();
        adapter.AddFragment(fragHue, "");
        fragHue.setArguments(bundle);
        //adapter.AddFragment(new FragmentNest(),"");
        //adapter.AddFragment(new FragmentBills(),"");
        //adapter.AddFragment(new FragmentNewGroup(),"");
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);

        tabLayout.getTabAt(0).setIcon(R.drawable.ic_hue);
        //tabLayout.getTabAt(1).setIcon(R.drawable.ic_nest);
        //tabLayout.getTabAt(2).setIcon(R.drawable.ic_bill);
        //tabLayout.getTabAt(3).setIcon(R.drawable.ic_add);

        //remove shadow

        ActionBar actionBar = getSupportActionBar();
        actionBar.setElevation(0);



        Spinner dropdown = (Spinner) findViewById(R.id.spinner);

        String[] items = new String[]{"+", "New User", "New Group"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);

        dropdown.setAdapter(adapter);

        dropdown.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i) {
                    case 0:
                        break;
                    case 1:

                        Intent myIntent = new Intent(MainActivity.this, NewUser.class);
                        myIntent.putExtra("house", user.getHouseID());
                        MainActivity.this.startActivity(myIntent);

                        break;
                    case 2:

                        myIntent = new Intent(MainActivity.this, NewGroup.class);
                        myIntent.putExtra("house", user.getHouseID());
                        MainActivity.this.startActivity(myIntent);

                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });



        //}

    }


    public void Restart(Context ctx)
    {
        ((MainActivity) ctx).recreate();
    }





}


