package user;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserDAO;

/**
 * Servlet implementation class NewUser
 */
@WebServlet("/NewUser")
public class NewUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NewUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		String username = request.getParameter("username");
	    String password = request.getParameter("password");
	    String houseID = request.getParameter("houseID");
	    int cost = 0;
	    
	    if(username == ""||password == "")
	    {
	    	response.sendError(422);
	    }
	    else
	    {
	    	if(houseID!=null)
	    	{
	    		UserDAO dao = new UserDAO();
		    	if(dao.getUser(username, password)==null)
		    	{
					User user = new User(username,password,houseID,cost);	
					dao.insertUser(user);
					response.setStatus(200);
		    	}
		    	else
		    	{
		    		response.sendError(401);
		    	}
	    	}
	    	else
	    	{
	    		response.sendError(500);
	    	}
	    }
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
