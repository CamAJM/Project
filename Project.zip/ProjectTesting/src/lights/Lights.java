package lights;
import java.util.ArrayList;

public class Lights extends attributes{

	String id;
	String groupID;
	String houseID;

	public Lights(String id, String type, String name, String modelid, String swversion, String on, 
			String bri, String hue, String sat, String xy, String ct, String alert, 
			String effect, String colormode, String reachable, String groupID, String houseID)
	{
		super(type, name, modelid, swversion, on, bri, hue, sat, xy, ct, 
				alert, effect,colormode, reachable);
		this.id = id;
		this.groupID = groupID;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	public String getGroupID() {
		return groupID;
	}

	public void setGroupID(String groupID) {
		this.groupID = groupID;
	}

	public String getHouseID() {
		return houseID;
	}

	public void setHouseID(String houseID) {
		this.houseID = houseID;
	}

	
	public String toString() 
	{
		String s = "{ \" " + getId() + "\": { \" state \" : { \" on \" : " 
						+ super.getOn() + ", \" bri \" : " 	+ super.getBri() + ", \" hue \" : " 
						+ super.getHue() + ", \" sat \" : " + super.getSat() + ", \" xy \" : " 
						+ super.getXy() + ", \" ct \" : " + super.getCt() + ", \" alert \" : \"" 
						+ super.getAlert() + "\", \" effect \" : \"" + super.getEffect() 
						+ "\", \" colormode \" : \"" + super.getColormode() + "\", \" reachable \" : " 
						+ super.getReachable() + "}, \" type \" : \"" + super.getType() + "\", \" name \" : \""
						+ super.getName() + "\", \" modelid \" : \"" + super.getModelid() + "\", \" swversion \" : \""
						+ super.getSwversion() + "\" },";
								
		return s;
	}
	
	public String toSQL()
	{
		int isOn;
		if(super.getOn() == "true")
		{
			isOn = 1;
		}
		else
		{
			isOn = 0;
		}
		String q = "\"" + getId() + "\"" + "," + "\"" + super.getType() + "\"" + "," + "\"" + super.getName() +"\"" +  "," + "\"" + super.getModelid() 
		+ "\"" + ","  + "\"" + super.getSwversion() + "\"" + "," + isOn + "," + super.getBri() + "," + super.getHue()
		+ "," + super.getSat() + "," + "\"" + super.getXy() + "\"" + "," + super.getCt() + "," + "\"" + super.getAlert() + 
		"\"" + "," + "\"" + super.getEffect() + "\"" + "," + "\"" + super.getColormode() + "\"" + "," + super.getReachable();
						
		return q;
	}
	
}
