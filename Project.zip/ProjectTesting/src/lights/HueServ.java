package lights;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.HueDAO;

/**
 * Servlet implementation class Serv
 */
@WebServlet("/HueServ")
public class HueServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HueServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// Gets the remaining parameters from what is entered.
		String id = request.getParameter("id");
		String type = request.getParameter("type");
		String name = request.getParameter("name");
		String modelid = request.getParameter("modelid");
		String swversion = request.getParameter("swversion");
		String on = request.getParameter("on");
		String bri = request.getParameter("bri");
		String hue = request.getParameter("hue");
		String sat = request.getParameter("sat");
		String xy = request.getParameter("xy");
		String ct = request.getParameter("ct");
		String alert = request.getParameter("alert");
		String effect = request.getParameter("effect");
		String colormode = request.getParameter("colormode");
		String reachable = request.getParameter("reachable");
		String groupID = request.getParameter("groupID");
		String houseID = request.getParameter("houseID");
		
		
		
		if(id == null)
		{
			System.out.print("Waiting for valid entries.");
		}
		else
		{
			Lights light = new Lights(id, type, name, modelid, swversion, on, bri, 
					hue, sat,xy, ct, alert, effect, colormode, reachable, groupID);
		
			
			light.toString();
			PrintWriter out = response.getWriter();
		
			out.print(light);
			System.out.println("Hello?");
			System.out.println(light);
			
			HueDAO dao = new HueDAO();
			
			dao.insertLight(light);
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
