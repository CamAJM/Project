import java.util.ArrayList;

public class Lights extends attributes{

	String id;
	
	public Lights(String id, String type, String name, String modelid, String swversion, String on, 
			String bri, String hue, String sat, String xy, String ct, String alert, 
			String effect, String colormode, String reachable)
	{
		super(type, name, modelid, swversion, on, bri, hue, sat, xy, ct, 
				alert, effect,colormode, reachable);
		this.id = id;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	
	public String toString() 
	{
		String s = "{ \" " + getId() + "\": { \" state \" : { \" on \" : " 
						+ super.getOn() + ", \" bri \" : " 	+ super.getBri() + ", \" hue \" : " 
						+ super.getHue() + ", \" sat \" : " + super.getSat() + ", \" xy \" : " 
						+ super.getXy() + ", \" ct \" : " + super.getCt() + ", \" alert \" : \"" 
						+ super.getAlert() + "\", \" effect \" : \"" + super.getEffect() 
						+ "\", \" colormode \" : \"" + super.getColormode() + "\", \" reachable \" : " 
						+ super.getReachable() + "}, \" type \" : \"" + super.getType() + "\", \" name \" : \""
						+ super.getName() + "\", \" modelid \" : \"" + super.getModelid() + "\", \" swversion \" : \""
						+ super.getSwversion() + "\" },";
								
		return s;
	}
	
}
