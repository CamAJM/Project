package nest;

public class Devices {

	// Default setup is thermostats alone.
	
	public Devices(String device_id, String locale,	String software_version,String structure_id,
			String name,String name_long,String last_connection,String is_online,String can_cool,
			String can_heat,String is_using_emergency_heat,String has_fan,String fan_timer_active,
			String fan_timer_timeout,String has_leaf,String temperature_scale,String target_temperature_f,
			String target_temperature_c,String target_temperature_high_f,String target_temperature_high_c,
			String target_temperature_low_f,String target_temperature_low_c,String eco_temperature_low_f,
			String eco_temperature_low_c,String eco_temperature_high_f,String eco_temperature_high_c,
			String away_temperature_low_f,String away_temperature_low_c,String away_temperature_high_f,
			String away_temperature_high_c,String hvac_mode,String previous_hvac_mode,
			String ambient_temperature_f,String ambient_temperature_c,String humidity,String hvac_state,
			String where_id,String is_locked,String locked_temp_min_f,String locked_temp_min_c,
			String locked_temp_max_f,String locked_temp_max_c,String label,String where_name,
			String sunlight_correction_enabled,String sunlight_correction_active,String fan_timer_duration,
			String time_to_target,String time_to_target_training)
	{
		Devices.device_id=device_id;
		Devices.locale=locale;
		Devices.software_version=software_version;
		Devices.structure_id=structure_id;
		Devices.name=name;
		Devices.name_long=name_long;
		Devices.last_connection=last_connection;
		Devices.is_online=is_online;
		Devices.can_cool=can_cool;
		Devices.can_heat=can_heat;
		Devices.is_using_emergency_heat=is_using_emergency_heat;
		Devices.has_fan=has_fan;
		Devices.fan_timer_active=fan_timer_active;
		Devices.fan_timer_timeout=fan_timer_timeout;
		Devices.has_leaf=has_leaf;
		Devices.temperature_scale=temperature_scale;
		Devices.target_temperature_f=target_temperature_f;
		Devices.target_temperature_c=target_temperature_c;
		Devices.target_temperature_high_f=target_temperature_high_f;
		Devices.target_temperature_high_c=target_temperature_high_c;
		Devices.target_temperature_low_f=target_temperature_low_f;
		Devices.target_temperature_low_c=target_temperature_low_c;
		Devices.eco_temperature_low_f=target_temperature_low_f;
		Devices.eco_temperature_low_c=target_temperature_low_c;
		Devices.eco_temperature_high_f=target_temperature_high_f;
		Devices.eco_temperature_high_c=target_temperature_high_c;
		Devices.away_temperature_low_f=away_temperature_low_f;
		Devices.away_temperature_low_c=away_temperature_low_c;
		Devices.away_temperature_high_f=away_temperature_high_f;
		Devices.away_temperature_high_c=away_temperature_high_c;
		Devices.hvac_mode=hvac_mode;
		Devices.previous_hvac_mode=previous_hvac_mode;
		Devices.ambient_temperature_f=ambient_temperature_f;
		Devices.ambient_temperature_c=ambient_temperature_c;
		Devices.humidity=humidity;
		Devices.hvac_state=hvac_state;
		Devices.where_id=where_id;
		Devices.is_locked=is_locked;
		Devices.locked_temp_min_f=locked_temp_min_f;
		Devices.locked_temp_min_c=locked_temp_min_c;
		Devices.locked_temp_max_f=locked_temp_max_f;
		Devices.locked_temp_max_c=locked_temp_max_c;
		Devices.label=label;
		Devices.where_name=where_name;
		Devices.sunlight_correction_enabled=sunlight_correction_enabled;
		Devices.sunlight_correction_active=sunlight_correction_active;
		Devices.fan_timer_duration=fan_timer_duration;
		Devices.time_to_target=time_to_target;
		Devices.time_to_target_training=time_to_target_training;
	}
	
	static String device_id;
	static String locale;
	static String software_version;
	static String structure_id;
	static String name;
	static String name_long;
	static String last_connection;
	static String is_online;
	static String can_cool;
	static String can_heat;
	static String is_using_emergency_heat;
	static String has_fan;
	static String fan_timer_active;
	static String fan_timer_timeout;
	static String has_leaf;
	static String temperature_scale;
	static String target_temperature_f;
	static String target_temperature_c;
	static String target_temperature_high_f;
	static String target_temperature_high_c;
	static String target_temperature_low_f;
	static String target_temperature_low_c;
	static String eco_temperature_low_f;
	static String eco_temperature_low_c;
	static String eco_temperature_high_f;
	static String eco_temperature_high_c;
	static String away_temperature_low_f;
	static String away_temperature_low_c;
	static String away_temperature_high_f;
	static String away_temperature_high_c;
	static String hvac_mode;
	static String previous_hvac_mode;
	static String ambient_temperature_f;
	static String ambient_temperature_c;
	static String humidity;
	static String hvac_state;
	static String where_id;
	static String is_locked;
	static String locked_temp_min_f;
	static String locked_temp_min_c;
	static String locked_temp_max_f;
	static String locked_temp_max_c;
	static String label;
	static String where_name;
	static String sunlight_correction_enabled;
	static String sunlight_correction_active;
	static String fan_timer_duration;
	static String time_to_target;
	static String time_to_target_training;
	public static String getDevice_id() {
		return device_id;
	}
	public static void setDevice_id(String device_id) {
		Devices.device_id = device_id;
	}
	public static String getLocale() {
		return locale;
	}
	public static void setLocale(String locale) {
		Devices.locale = locale;
	}
	public static String getSoftware_version() {
		return software_version;
	}
	public static void setSoftware_version(String software_version) {
		Devices.software_version = software_version;
	}
	public static String getStructure_id() {
		return structure_id;
	}
	public static void setStructure_id(String structure_id) {
		Devices.structure_id = structure_id;
	}
	public static String getName() {
		return name;
	}
	public static void setName(String name) {
		Devices.name = name;
	}
	public static String getName_long() {
		return name_long;
	}
	public static void setName_long(String name_long) {
		Devices.name_long = name_long;
	}
	public static String getLast_connection() {
		return last_connection;
	}
	public static void setLast_connection(String last_connection) {
		Devices.last_connection = last_connection;
	}
	public static String isIs_online() {
		return is_online;
	}
	public static void setIs_online(String is_online) {
		Devices.is_online = is_online;
	}
	public static String isCan_cool() {
		return can_cool;
	}
	public static void setCan_cool(String can_cool) {
		Devices.can_cool = can_cool;
	}
	public static String isCan_heat() {
		return can_heat;
	}
	public static void setCan_heat(String can_heat) {
		Devices.can_heat = can_heat;
	}
	public static String isIs_using_emergency_heat() {
		return is_using_emergency_heat;
	}
	public static void setIs_using_emergency_heat(String is_using_emergency_heat) {
		Devices.is_using_emergency_heat = is_using_emergency_heat;
	}
	public static String isHas_fan() {
		return has_fan;
	}
	public static void setHas_fan(String has_fan) {
		Devices.has_fan = has_fan;
	}
	public static String isFan_timer_active() {
		return fan_timer_active;
	}
	public static void setFan_timer_active(String fan_timer_active) {
		Devices.fan_timer_active = fan_timer_active;
	}
	public static String getFan_timer_timeout() {
		return fan_timer_timeout;
	}
	public static void setFan_timer_timeout(String fan_timer_timeout) {
		Devices.fan_timer_timeout = fan_timer_timeout;
	}
	public static String isHas_leaf() {
		return has_leaf;
	}
	public static void setHas_leaf(String has_leaf) {
		Devices.has_leaf = has_leaf;
	}
	public static String getTemperature_scale() {
		return temperature_scale;
	}
	public static void setTemperature_scale(String temperature_scale) {
		Devices.temperature_scale = temperature_scale;
	}
	public static String getTarget_temperature_f() {
		return target_temperature_f;
	}
	public static void setTarget_temperature_f(String target_temperature_f) {
		Devices.target_temperature_f = target_temperature_f;
	}
	public static String getTarget_temperature_c() {
		return target_temperature_c;
	}
	public static void setTarget_temperature_c(String target_temperature_c) {
		Devices.target_temperature_c = target_temperature_c;
	}
	public static String getTarget_temperature_high_f() {
		return target_temperature_high_f;
	}
	public static void setTarget_temperature_high_f(String target_temperature_high_f) {
		Devices.target_temperature_high_f = target_temperature_high_f;
	}
	public static String getTarget_temperature_high_c() {
		return target_temperature_high_c;
	}
	public static void setTarget_temperature_high_c(String target_temperature_high_c) {
		Devices.target_temperature_high_c = target_temperature_high_c;
	}
	public static String getTarget_temperature_low_f() {
		return target_temperature_low_f;
	}
	public static void setTarget_temperature_low_f(String target_temperature_low_f) {
		Devices.target_temperature_low_f = target_temperature_low_f;
	}
	public static String getTarget_temperature_low_c() {
		return target_temperature_low_c;
	}
	public static void setTarget_temperature_low_c(String target_temperature_low_c) {
		Devices.target_temperature_low_c = target_temperature_low_c;
	}
	public static String getEco_temperature_low_f() {
		return eco_temperature_low_f;
	}
	public static void setEco_temperature_low_f(String eco_temperature_low_f) {
		Devices.eco_temperature_low_f = eco_temperature_low_f;
	}
	public static String getEco_temperature_low_c() {
		return eco_temperature_low_c;
	}
	public static void setEco_temperature_low_c(String eco_temperature_low_c) {
		Devices.eco_temperature_low_c = eco_temperature_low_c;
	}
	public static String getEco_temperature_high_f() {
		return eco_temperature_high_f;
	}
	public static void setEco_temperature_high_f(String eco_temperature_high_f) {
		Devices.eco_temperature_high_f = eco_temperature_high_f;
	}
	public static String getEco_temperature_high_c() {
		return eco_temperature_high_c;
	}
	public static void setEco_temperature_high_c(String eco_temperature_high_c) {
		Devices.eco_temperature_high_c = eco_temperature_high_c;
	}
	public static String getAway_temperature_low_f() {
		return away_temperature_low_f;
	}
	public static void setAway_temperature_low_f(String away_temperature_low_f) {
		Devices.away_temperature_low_f = away_temperature_low_f;
	}
	public static String getAway_temperature_low_c() {
		return away_temperature_low_c;
	}
	public static void setAway_temperature_low_c(String away_temperature_low_c) {
		Devices.away_temperature_low_c = away_temperature_low_c;
	}
	public static String getAway_temperature_high_f() {
		return away_temperature_high_f;
	}
	public static void setAway_temperature_high_f(String away_temperature_high_f) {
		Devices.away_temperature_high_f = away_temperature_high_f;
	}
	public static String getAway_temperature_high_c() {
		return away_temperature_high_c;
	}
	public static void setAway_temperature_high_c(String away_temperature_high_c) {
		Devices.away_temperature_high_c = away_temperature_high_c;
	}
	public static String getHvac_mode() {
		return hvac_mode;
	}
	public static void setHvac_mode(String hvac_mode) {
		Devices.hvac_mode = hvac_mode;
	}
	public static String getPrevious_hvac_mode() {
		return previous_hvac_mode;
	}
	public static void setPrevious_hvac_mode(String previous_hvac_mode) {
		Devices.previous_hvac_mode = previous_hvac_mode;
	}
	public static String getAmbient_temperature_f() {
		return ambient_temperature_f;
	}
	public static void setAmbient_temperature_f(String ambient_temperature_f) {
		Devices.ambient_temperature_f = ambient_temperature_f;
	}
	public static String getAmbient_temperature_c() {
		return ambient_temperature_c;
	}
	public static void setAmbient_temperature_c(String ambient_temperature_c) {
		Devices.ambient_temperature_c = ambient_temperature_c;
	}
	public static String getHumidity() {
		return humidity;
	}
	public static void setHumidity(String humidity) {
		Devices.humidity = humidity;
	}
	public static String getHvac_state() {
		return hvac_state;
	}
	public static void setHvac_state(String hvac_state) {
		Devices.hvac_state = hvac_state;
	}
	public static String getWhere_id() {
		return where_id;
	}
	public static void setWhere_id(String where_id) {
		Devices.where_id = where_id;
	}
	public static String isIs_locked() {
		return is_locked;
	}
	public static void setIs_locked(String is_locked) {
		Devices.is_locked = is_locked;
	}
	public static String getLocked_temp_min_f() {
		return locked_temp_min_f;
	}
	public static void setLocked_temp_min_f(String locked_temp_min_f) {
		Devices.locked_temp_min_f = locked_temp_min_f;
	}
	public static String getLocked_temp_min_c() {
		return locked_temp_min_c;
	}
	public static void setLocked_temp_min_c(String locked_temp_min_c) {
		Devices.locked_temp_min_c = locked_temp_min_c;
	}
	public static String getLocked_temp_max_f() {
		return locked_temp_max_f;
	}
	public static void setLocked_temp_max_f(String locked_temp_max_f) {
		Devices.locked_temp_max_f = locked_temp_max_f;
	}
	public static String getLocked_temp_max_c() {
		return locked_temp_max_c;
	}
	public static void setLocked_temp_max_c(String locked_temp_max_c) {
		Devices.locked_temp_max_c = locked_temp_max_c;
	}
	public static String getLabel() {
		return label;
	}
	public static void setLabel(String label) {
		Devices.label = label;
	}
	public static String getWhere_name() {
		return where_name;
	}
	public static void setWhere_name(String where_name) {
		Devices.where_name = where_name;
	}
	public static String isSunlight_correction_enabled() {
		return sunlight_correction_enabled;
	}
	public static void setSunlight_correction_enabled(String sunlight_correction_enabled) {
		Devices.sunlight_correction_enabled = sunlight_correction_enabled;
	}
	public static String isSunlight_correction_active() {
		return sunlight_correction_active;
	}
	public static void setSunlight_correction_active(String sunlight_correction_active) {
		Devices.sunlight_correction_active = sunlight_correction_active;
	}
	public static String getFan_timer_duration() {
		return fan_timer_duration;
	}
	public static void setFan_timer_duration(String fan_timer_duration) {
		Devices.fan_timer_duration = fan_timer_duration;
	}
	public static String getTime_to_target() {
		return time_to_target;
	}
	public static void setTime_to_target(String time_to_target) {
		Devices.time_to_target = time_to_target;
	}
	public static String getTime_to_target_training() {
		return time_to_target_training;
	}
	public static void setTime_to_target_training(String time_to_target_training) {
		Devices.time_to_target_training = time_to_target_training;
	}
	

		


	
	
}
