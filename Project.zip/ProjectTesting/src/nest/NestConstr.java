package nest;

public class NestConstr{

	
	public NestConstr(String access_token, String client_version,String device_id, String locale,String software_version,String structure_id,
			String name,String name_long,String last_connection,String is_online,String can_cool,
			String can_heat,String is_using_emergency_heat,String has_fan,String fan_timer_active,
			String fan_timer_timeout,String has_leaf,String temperature_scale,String target_temperature_f,
			String target_temperature_c,String target_temperature_high_f,String target_temperature_high_c,
			String target_temperature_low_f,String target_temperature_low_c,String eco_temperature_low_f,
			String eco_temperature_low_c,String eco_temperature_high_f,String eco_temperature_high_c,
			String away_temperature_low_f,String away_temperature_low_c,String away_temperature_high_f,
			String away_temperature_high_c,String hvac_mode,String previous_hvac_mode,
			String ambient_temperature_f,String ambient_temperature_c,String humidity,String hvac_state,
			String where_id,String is_locked,String locked_temp_min_f,String locked_temp_min_c,
			String locked_temp_max_f,String locked_temp_max_c,String label,String where_name,
			String sunlight_correction_enabled,String sunlight_correction_active,String fan_timer_duration,
			String time_to_target,String time_to_target_training, String thermostats, String away, String sName, String country_code,
			String peak_period_start_time,String peak_period_end_time,String time_zone, String wName)
	{
		
		//MetaData
		Metadata.access_token = access_token;
		Metadata.client_version = client_version;
		
		//Devices
		Devices.device_id=device_id;
		Devices.locale=locale;
		Devices.software_version=software_version;
		Devices.structure_id=structure_id;
		Devices.name=name;
		Devices.name_long=name_long;
		Devices.last_connection=last_connection;
		Devices.is_online=is_online;
		Devices.can_cool=can_cool;
		Devices.can_heat=can_heat;
		Devices.is_using_emergency_heat=is_using_emergency_heat;
		Devices.has_fan=has_fan;
		Devices.fan_timer_active=fan_timer_active;
		Devices.fan_timer_timeout=fan_timer_timeout;
		Devices.has_leaf=has_leaf;
		Devices.temperature_scale=temperature_scale;
		Devices.target_temperature_f=target_temperature_f;
		Devices.target_temperature_c=target_temperature_c;
		Devices.target_temperature_high_f=target_temperature_high_f;
		Devices.target_temperature_high_c=target_temperature_high_c;
		Devices.target_temperature_low_f=target_temperature_low_f;
		Devices.target_temperature_low_c=target_temperature_low_c;
		Devices.eco_temperature_low_f=target_temperature_low_f;
		Devices.eco_temperature_low_c=target_temperature_low_c;
		Devices.eco_temperature_high_f=target_temperature_high_f;
		Devices.eco_temperature_high_c=target_temperature_high_c;
		Devices.away_temperature_low_f=away_temperature_low_f;
		Devices.away_temperature_low_c=away_temperature_low_c;
		Devices.away_temperature_high_f=away_temperature_high_f;
		Devices.away_temperature_high_c=away_temperature_high_c;
		Devices.hvac_mode=hvac_mode;
		Devices.previous_hvac_mode=previous_hvac_mode;
		Devices.ambient_temperature_f=ambient_temperature_f;
		Devices.ambient_temperature_c=ambient_temperature_c;
		Devices.humidity=humidity;
		Devices.hvac_state=hvac_state;
		Devices.where_id=where_id;
		Devices.is_locked=is_locked;
		Devices.locked_temp_min_f=locked_temp_min_f;
		Devices.locked_temp_min_c=locked_temp_min_c;
		Devices.locked_temp_max_f=locked_temp_max_f;
		Devices.locked_temp_max_c=locked_temp_max_c;
		Devices.label=label;
		Devices.where_name=where_name;
		Devices.sunlight_correction_enabled=sunlight_correction_enabled;
		Devices.sunlight_correction_active=sunlight_correction_active;
		Devices.fan_timer_duration=fan_timer_duration;
		Devices.time_to_target=time_to_target;
		Devices.time_to_target_training=time_to_target_training;
		
		//Structures
		
		Structures.structure_id = structure_id;
		Structures.thermostats = thermostats;
		Structures.away = away;
		Structures.sName = sName;
		Structures.country_code = country_code;
		Structures.peak_period_start_time = peak_period_start_time;
		Structures.peak_period_end_time = peak_period_end_time;
		Structures.time_zone = time_zone;
		
		//Wheres
		
		Wheres.where_id = where_id;
		Wheres.name = name;
		
	}
	public String toString() 
	{
		// Needs correcting. Speech marks are not needed for ints.
		String s = "{ \" metadata \": { \" access_token \": " + Metadata.getAccess_token() + 
				", \"client_version \":" + Metadata.getClient_version() +
				"},"+
				"\"devices\": { "+
				"\"thermostats \": { "+
				"\""+Devices.getDevice_id()+ "\": {"+
				"\"device_id\":"+"\""+Devices.getDevice_id()+ "\","+
				"\"locale\":"+ "\"" + Devices.getLocale() + "\","+
				"\"software_version\":"+"\""+Devices.getSoftware_version()+ "\","+
				"\"structure_id\":"+ "\"" + Devices.getStructure_id() + "\","+
				"\"name\":"+"\""+Devices.getName()+ "\","+
				"\"name_long\":"+ "\"" + Devices.getName_long() + "\","+
				"\"last_connection\":"+"\""+Devices.getLast_connection()+ "\","+
				"\"is_online\":" + Devices.isIs_online() + ","+
				"\"can_cool\":"+Devices.isCan_cool()+ ","+
				"\"can_heat\":"+ Devices.isCan_heat() + ","+
				"\"is_using_emergency_heat\":"+Devices.isIs_using_emergency_heat()+ ","+
				"\"has_fan\":"+ Devices.isHas_fan() + ","+
				"\"fan_timer_active\":"+Devices.isFan_timer_active()+ ","+
				"\"fan_timer_timeout\":"+ "\"" + Devices.getFan_timer_timeout() + "\","+
				"\"has_leaf\":"+Devices.isHas_leaf()+ ","+
				"\"temperature_scale\":"+ "\"" + Devices.getTemperature_scale() + "\","+
				"\"target_temperature_f\":"+Devices.getTarget_temperature_f()+ ","+
				"\"target_temperature_c\":"+Devices.getTarget_temperature_c()+ ","+
				"\"target_temperature_high_f\":"+Devices.getTarget_temperature_high_f()+ ","+
				"\"target_temperature_high_c\":"+Devices.getTarget_temperature_high_c()+ ","+
				"\"target_temperature_low_f\":"+Devices.getTarget_temperature_low_f()+ ","+
				"\"target_temperature_low_c\":"+Devices.getTarget_temperature_low_c()+ ","+
				"\"eco_temperature_high_f \":" +Devices.getEco_temperature_high_f()+ ","+
				"\"eco_temperature_high_c \":" +Devices.getEco_temperature_high_c()+ ","+
				"\"eco_temperature_low_f\":" +Devices.getEco_temperature_low_f()+ ","+
				"\"eco_temperature_low_c\":" +Devices.getEco_temperature_low_c()+ ","+
				"\"away_temperature_high_f\":" +Devices.getAway_temperature_high_f()+ ","+
				"\"away_temperature_high_c\":" +Devices.getAway_temperature_high_c()+ ","+
				"\"away_temperature_low_f\":" +Devices.getAway_temperature_low_f()+ ","+
				"\"away_temperature_low_c\":" +Devices.getAway_temperature_low_c()+ ","+
				"\"hvac_mode\":" +Devices.getHvac_mode()+ ","+
				"\"previous_hvac_mode\":" +"\""+Devices.getPrevious_hvac_mode()+ "\","+
				"\"ambient_temperature_f\":" +Devices.getAmbient_temperature_f()+ ","+
				"\"ambient_temperature_c\":" +Devices.getAmbient_temperature_c()+ ","+
				"\"humidity\":" +Devices.getHumidity()+","+
				"\"hvac_state\":" +"\""+Devices.getHvac_state()+ "\","+
				"\"where_id\":" +"\""+Devices.getWhere_id()+"\","+
				"\"is_locked\":" +Devices.isIs_locked()+","+
				"\"locked_temp_min_f\":" +"\""+Devices.getLocked_temp_min_f()+"\","+
				"\"locked_temp_max_f\":" +"\""+Devices.getLocked_temp_max_f()+"\","+
				"\"locked_temp_min_c\":" +"\""+Devices.getLocked_temp_min_c()+"\","+
				"\"locked_temp_max_c\":" +"\""+Devices.getLocked_temp_max_c()+"\","+
				"\"label\":" +"\""+Devices.getLabel()+"\","+
				"\"where_name\":" +"\""+Devices.getWhere_name()+"\","+
				"\"sunlight_correction_enabled\":" +Devices.isSunlight_correction_enabled()+","+
				"\"sunlight_correction_active\":" +Devices.isSunlight_correction_active()+","+
				"\"fan_timer_duration\":" +Devices.getFan_timer_duration()+","+
				"\"time_to_target\":" +"\""+Devices.getTime_to_target()+"\","+
				"\"time_to_target_training\":" +"\""+Devices.getTime_to_target_training()+"\""+
				"}"+
				"},"+
				"},"+
				"\"structures\": { "+
				"\"structure_id\":"+"\""+Structures.getStructure_id() +"\","+
				"\"thermostats\":"+"\""+Structures.getThermostats()+"\","+
				"\"away\":"+"\""+Structures.getAway() +"\","+
				"\"sName\":"+"\""+Structures.getsName()+"\","+
				"\"peak_period_start_time\":"+"\""+Structures.getPeak_period_start_time() +"\","+
				"\"peak_period_end_time\":"+"\""+Structures.getPeak_period_end_time() +"\","+
				"\"time_zone\":"+"\""+Structures.getTime_zone()+"\","+
				"\"wheres\": { "+
				"\""+Wheres.getWhere_id()+"\"{"+
				"\"where_id\":"+"\""+Wheres.getWhere_id() +"\","+
				"\"name\":"+"\""+Wheres.getName() +"\""+
				"}"+
				"}"+
				"}"+
				"}";
				
		
				
								
		return s;
	}
}

