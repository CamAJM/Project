package nest;

public class Metadata {

	// call access_token and client_version
	
	static String access_token;
	static String client_version;
	
	public Metadata(String access_token, String client_version)
	{
		Metadata.access_token = access_token;
		Metadata.client_version = client_version;
	}
	
	public static String getAccess_token() {
		return access_token;
	}
	public static void setAccess_token(String access_token) {
		Metadata.access_token = access_token;
	}
	public static String getClient_version() {
		return client_version;
	}
	public static void setClient_version(String client_version) {
		Metadata.client_version = client_version;
	}
}
