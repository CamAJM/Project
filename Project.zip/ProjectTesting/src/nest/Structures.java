package nest;

public class Structures extends Wheres{

	// structure_id etc
	
	static String thermostats;
	static String structure_id;
	static String away;
	static String sName;
	static String country_code;
	static String peak_period_start_time;
	static String peak_period_end_time;
	static String time_zone;
	

	public Structures(String structure_id, String thermostats, String away, String sName, String country_code,
			String peak_period_start_time,String peak_period_end_time,String time_zone)
	{
		super(where_id, name);
		
		Structures.structure_id = structure_id;
		Structures.thermostats = thermostats;
		Structures.away = away;
		Structures.sName = sName;
		Structures.country_code = country_code;
		Structures.peak_period_start_time = peak_period_start_time;
		Structures.peak_period_end_time = peak_period_end_time;
		Structures.time_zone = time_zone;
				
	}


	public static String getThermostats() {
		return thermostats;
	}


	public static void setThermostats(String thermostats) {
		Structures.thermostats = thermostats;
	}


	public static String getStructure_id() {
		return structure_id;
	}


	public static void setStructure_id(String structure_id) {
		Structures.structure_id = structure_id;
	}


	public static String getAway() {
		return away;
	}


	public static void setAway(String away) {
		Structures.away = away;
	}


	public static String getsName() {
		return sName;
	}


	public static void setsName(String sName) {
		Structures.sName = sName;
	}


	public static String getCountry_code() {
		return country_code;
	}


	public static void setCountry_code(String country_code) {
		Structures.country_code = country_code;
	}


	public static String getPeak_period_start_time() {
		return peak_period_start_time;
	}


	public static void setPeak_period_start_time(String peak_period_start_time) {
		Structures.peak_period_start_time = peak_period_start_time;
	}


	public static String getPeak_period_end_time() {
		return peak_period_end_time;
	}


	public static void setPeak_period_end_time(String peak_period_end_time) {
		Structures.peak_period_end_time = peak_period_end_time;
	}


	public static String getTime_zone() {
		return time_zone;
	}


	public static void setTime_zone(String time_zone) {
		Structures.time_zone = time_zone;
	}
	
	
}
