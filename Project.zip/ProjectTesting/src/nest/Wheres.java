package nest;

public class Wheres {
	
	static String where_id;
	static String name;

	public Wheres(String where_id, String name)
	{
		Wheres.where_id = where_id;
		Wheres.name = name;
	}

	public static String getWhere_id() {
		return where_id;
	}

	public static void setWhere_id(String where_id) {
		Wheres.where_id = where_id;
	}

	public static String getName() {
		return name;
	}

	public static void setName(String name) {
		Wheres.name = name;
	}

	

}
