package group;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import dao.GroupsDAO;
import dao.HueDAO;
import lights.Lights;

/**
 * Servlet implementation class getAllByHouse
 */
@WebServlet("/GetLightsByGroup")
public class GetLightsByGroup extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetLightsByGroup() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HueDAO dao = new HueDAO();
		
		// BROKEN
		
		// DO NOT USE!
		
		String id = request.getParameter("id");
		
		if(id != null)
		{
			//ArrayList<Lights> arrLight = dao.findAllByGroup(id);
			
			//System.out.println(arrLight);
			
			//String json = new Gson().toJson(arrLight);
			
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			//response.getWriter().write(json);
		}
		else
		{
			response.sendError(422);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
