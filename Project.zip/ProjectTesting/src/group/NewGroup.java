package group;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.GroupsDAO;

/**
 * Servlet implementation class NewGroup
 */
@WebServlet("/NewGroup")
public class NewGroup extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NewGroup() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		GroupsDAO dao = new GroupsDAO();
		String gName = request.getParameter("gName");
		String type = request.getParameter("type");
		String status = "0";
		String houseID = request.getParameter("houseID");

		System.out.println(houseID);
		
		if(gName != "" && type != null && houseID != "")
		{		
			
			if(type.matches("NestGroup"))
			{
				Group group = dao.nestCheck(houseID);

				if(group == null)
				{
					if(dao.searchGroups(gName, houseID)==null)
					{
	
						int latest = dao.getLatest();
						
						latest = latest+1;
								
						if(latest == 0)
						{
							response.sendError(500);
						}
						else
						{
							Group newGroup = new Group(latest,gName,type,status,houseID);
							dao.insertGroup(newGroup);
							dao.connectNest(latest, type, houseID);
							response.setStatus(200);
						}
					}
					else
					{
						response.sendError(400);
					}
					
				}
				else
				{
					response.sendError(401);
				}		
			}
			else if(type.matches("LightGroup"))
			{
				Group oneGroup = dao.searchGroups(gName, houseID);
								
				if(oneGroup==null)
				{
					int latest = dao.getLatest();
					
					latest = latest+1;
						
					if(latest == 0)
					{
						response.sendError(500);
					}
					else
					{
						Group newGroup = new Group(latest,gName,type,status,houseID);
						dao.insertGroup(newGroup);
						dao.connectLights(latest, type, houseID);
						response.setStatus(200);
					}
				}
				else
				{
					response.sendError(400);
				}
			
			}
			else
			{
				response.sendError(500);
			}
			
			
		}
		else
		{
			response.sendError(422);
		}
		
		

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
