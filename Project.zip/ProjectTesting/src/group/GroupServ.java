package group;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.GroupsDAO;
import dao.HueDAO;
import lights.Lights;

/**
 * Servlet implementation class Serv
 */
@WebServlet("/GroupServ")
public class GroupServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GroupServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// Select a group
		// Check DAO for all lights where the group is a match.
		// Add each to an arraylist
		// Update each
		
		String groupID = request.getParameter("id");
		
		ArrayList<Lights> all = new ArrayList<Lights>();
		PrintWriter out = response.getWriter();
		HueDAO dao = new HueDAO();


		if(groupID != null)
		{
			
			all = dao.findAllByGroup(groupID);
			
			System.out.println(all);
			out.print(all);
		}
		else
		{
			System.out.print("Waiting for a valid group id.");
		}
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
