package group;

public class Group {


    int groupID;
    String gName;
    String type;
    String houseID;
    String status;
    

    public Group(int groupID, String gName, String type, String status, String houseID) {
        this.groupID = groupID;
        this.gName = gName;
        this.type = type;
        this.houseID = houseID;
        this.status = status;
    }


    public int getGroupID() {
        return groupID;
    }

    public void setGroupID(int groupID) {
        this.groupID = groupID;
    }

    public String getgName() {
        return gName;
    }

    public void setgName(String gName) {
        this.gName = gName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
    public String getStatus()
    {
    	return status;
    }
    
    public void setStatus(String status)
    {
    	this.status = status;
    }

    public String getHouseID() {
        return houseID;
    }

    public void setHouseID(String houseID) {
        this.houseID = houseID;
    }
    
   

    public String toString() {
    	
    	String isOn = "";
    	
    	if(getStatus() == "1")
    	{
    		isOn = "Online";
    	}
    	else 
    	{
    		isOn = "False";
    	}
    	
        String s = getgName() + " Status:" + isOn ;

        return s;
    }

    public String toSQL() {
        String s = getGroupID() + "," + "\"" + getgName() + "\",\"" + getType() + "\",\"" + getStatus() + "\",\"" + getHouseID() + "\"";
        return s;
    }
}
