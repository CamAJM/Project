package group;


import java.util.ArrayList;

import lights.Lights;

public class Group {

	
	
	String groupID;
	String gName;
	String type;
	
	
	public Group(String groupID,String gName,String type) 
	{
		this.groupID = groupID;
		this.gName = gName;
		this.type = type;
	}


	
	
	/*
	public String toString() 
	{
	
		//Take in the arraylist. For each entry in arraylist, do this with a different getLights().
		String s = "{ \" " + getId() + "\": { \" name \" : "
				 + super.getName() + ", \" lights \" : [ " 	
				 + super.getLights() + " ], \" type \" : " 
				 + super.getType() + ", \" action \" : { \" on \" : " 
				 + super.getOn() + ", \" bri \" :  " 
				 + super.getBri() + ", \" hue \" : "
				 + super.getHue() + ", \" sat \" : "
				 + super.getSat() + ", \" effect \" : "
				 + super.getEffect() + ", \" xy \" : "
				 + super.getXy() + ", \" ct \" : " 
				 + super.getCt() +  ", \" alert \" : "
				 + super.getAlert() +  ", \" alert \" : "
				 + super.getAlert() +  ", \" colormode \" : "
				 + super.getColormode() +  "\" }  },";
		
		return s;
	}		
	*/ 

}
