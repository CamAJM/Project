package dao;


import java.util.ArrayList;

import lights.Lights;

import java.sql.*;
import nest.NestConstr;


public class NestDAO {
	
	
	NestConstr oneNest = null;
	Connection conn = null;
    Statement stmt = null;

	public NestDAO() {}

	
	public void openConnection(){
		// loading jdbc driver for mysql
		try{
		    Class.forName("com.mysql.jdbc.Driver").newInstance();
		} catch(Exception e) { System.out.println(e); }

		// connecting to database
		try{
			// connection string for demos database, username demos, password demos
			// connect to cloud server for SQL database here 
		    conn = DriverManager.getConnection
	        ("jdbc:mysql://mudfoot.doc.stu.mmu.ac.uk:3306/whitej?user=whitej&password=Uclefask3");
		 //  ("jdbc:sqlite:films.sqlite");
		    stmt = conn.createStatement();
		} catch(SQLException se) { System.out.println(se); }	   
    }
	private void closeConnection(){
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private NestConstr getNextNest(ResultSet rs){
    	NestConstr thisLight=null;
    	try {
			thisLight = new NestConstr(
					rs.getString("access_token"),
					rs.getString("client_version"),
					rs.getString("device_id"),
					rs.getString("locale"),
					rs.getString("software_version"),
					rs.getString("structure_id"),
					rs.getString("name"),
					rs.getString("name_long"),
					rs.getString("last_connection"),
					rs.getString("is_online"),
					rs.getString("can_cool"),
					rs.getString("can_heat"),
					rs.getString("is_using_emergency_heat"),
					rs.getString("has_fan"),
					rs.getString("fan_timer_active"),
					rs.getString("fan_timer_timeout"),
					rs.getString("has_leaf"),
					rs.getString("temperature_scale"),
					rs.getString("target_temperature_f"),
					rs.getString("target_temperature_c"),
					rs.getString("target_temperature_high_f"),
					rs.getString("target_temperature_high_c"),
					rs.getString("target_temperature_low_f"),
					rs.getString("target_temperature_low_c"),
					rs.getString("eco_temperature_high_f"),
					rs.getString("eco_temperature_high_c"),
					rs.getString("eco_temperature_low_f"),
					rs.getString("eco_temperature_low_c"),
					rs.getString("away_temperature_high_f"),
					rs.getString("away_temperature_high_c"),
					rs.getString("away_temperature_low_f"),
					rs.getString("away_temperature_low_c"),
					rs.getString("hvac_mode"),
					rs.getString("previous_hvac_mode"),
					rs.getString("ambient_temperature_f"),
					rs.getString("ambient_temperature_c"),
					rs.getString("humidity"),
					rs.getString("hvac_state"),
					rs.getString("where_id"),
					rs.getString("is_locked"),
					rs.getString("locked_temp_min_f"),
					rs.getString("locked_temp_min_c"),
					rs.getString("locked_temp_max_f"),
					rs.getString("locked_temp_max_c"),
					rs.getString("label"),
					rs.getString("where_name"),
					rs.getString("sunlight_correction_enabled"),
					rs.getString("sunlight_correction_active"),
					rs.getString("fan_timer_duration"),
					rs.getString("time_to_target"),
					rs.getString("time_to_target_training"));
					
					
					
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return thisLight;			
	}
	

   public NestConstr insertNest(NestConstr insert) {
		   
		System.out.println(insert);
		
		openConnection();
		oneNest= null;
		
		
		try {
			String selectSQL = "insert into nest VALUES("+insert.toSQL()+");";
			System.out.println(selectSQL);

			stmt.executeUpdate(selectSQL);
			   //TODO need to set up a second sql statment 
			   
			  System.out.println("Added to the database");

			    stmt.close();
			    closeConnection();
			} catch(SQLException se) { System.out.println(se); }
		
		
		return oneNest;
	}

	
	public ArrayList<NestConstr> findAllByGroup(String id) {
	// TODO Auto-generated method stub
		
		ArrayList<NestConstr> list = new ArrayList<NestConstr>();

		openConnection();
		
		
		
		try{
			String selectSQL = "SELECT * FROM nest WHERE groupID ="+id+";";
			ResultSet rs1 = stmt.executeQuery(selectSQL);
		    // Retrieve the results
		    
		    while(rs1.next()){
		    	oneNest = getNextNest(rs1);
		    	list.add(oneNest);
		    }
		   

		    stmt.close();
		} catch(SQLException se) { System.out.println(se); }

		
		return list;
		
			
		
	}				
				
   
   
   
}
