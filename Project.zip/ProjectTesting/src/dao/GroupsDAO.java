package dao;


import java.util.ArrayList;

import group.Group;

import java.sql.*;
import java.text.ParseException;

import lights.Lights;


public class GroupsDAO {
	
	ArrayList<Group> list = new ArrayList<Group>();
	Group oneGroup = null;
	Connection conn = null;
    Statement stmt = null;

	public GroupsDAO() {}

	
	public void openConnection(){
		// loading jdbc driver for mysql
		try{
		    Class.forName("com.mysql.jdbc.Driver").newInstance();
		} catch(Exception e) { System.out.println(e); }

		// connecting to database
		try{
			// connection string for demos database, username demos, password demos
			// connect to cloud server for SQL database here 
		    conn = DriverManager.getConnection
	        ("jdbc:mysql://mudfoot.doc.stu.mmu.ac.uk:3306/whitej?user=whitej&password=Uclefask3");
		 //  ("jdbc:sqlite:films.sqlite");
		    stmt = conn.createStatement();
		} catch(SQLException se) { System.out.println(se); }	   
    }
	private void closeConnection(){
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private Group getNextGroup(ResultSet rs){
    	Group thisGroup=null;
    	try {
			thisGroup = new Group(
					rs.getInt("groupID"),
					rs.getString("gName"),
					rs.getString("type"),
					rs.getString("status"),
					rs.getString("houseID"));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return thisGroup;			
	}
	
	// Update Query. Turns off/on all lights
	
	public int changeTemp(String id, int C, int F)
	{		
		openConnection();
		oneGroup= null;
		int result = 0;
				
		
		try {
			String selectSQL = "UPDATE Groups g, nest n"+		
					" SET g.`status`="+C+", n.target_temperature_c="+C+", n.target_temperature_f="+F+
					" WHERE g.groupID="+id+" && n.groupID="+id+";";
			  stmt.executeUpdate(selectSQL);
			   //TODO need to set up a second sql statment 
			   
			  System.out.println("Lights have been turned off");

			    stmt.close();
			    closeConnection();
			} catch(SQLException se) { System.out.println(se); }
		
		return result;
		
		
	}
	public void turnOffGroups(String id)
	{		
		openConnection();
		oneGroup= null;
		
		
		try {
			String selectSQL = "UPDATE Groups g, Lights l "+
					"SET g.`status`=\"0\", l.`on`=0 "+
					"WHERE g.groupID="+id+" && l.groupID="+id+";";
			  stmt.executeUpdate(selectSQL);
			   //TODO need to set up a second sql statment 
			   
			  System.out.println("Lights have been turned off");

			    stmt.close();
			    closeConnection();
			} catch(SQLException se) { System.out.println(se); }
		
	}
	
	public void turnOnGroups(String id)
	{
		openConnection();
		oneGroup= null;
		
		
		try {
			String selectSQL = "UPDATE Groups g, Lights l"+
					" SET g.`status`=\"1\", l.`on`=1"+
					" WHERE g.groupID="+id+" && l.groupID="+id+";";
			
			  System.out.println(selectSQL);
			  stmt.executeUpdate(selectSQL);
			   //TODO need to set up a second sql statment 
			   
			  System.out.println("Lights have been turned on");

			    stmt.close();
			    closeConnection();
			} catch(SQLException se) { System.out.println(se); }
	}
	 
	public int getLatest()
    {

        openConnection();

        try{
            String selectSQL = "SELECT * FROM Groups ORDER BY groupID DESC LIMIT 1";

            ResultSet rs1 = stmt.executeQuery(selectSQL);

            while(rs1.next())
            {
                oneGroup = getNextGroup(rs1);

            }

        }
        catch (SQLException se) {System.out.println(se);}

        return oneGroup.getGroupID();
    }

    public Group searchGroups(String name, String id)
    {
        openConnection();

        try{
            String selectSQL = "SELECT * FROM Groups WHERE gName =\""+name+"\" && houseID = \""+id+"\";";
            ResultSet rs1 = stmt.executeQuery(selectSQL);
            // Retrieve the results

            while(rs1.next()){
                oneGroup = getNextGroup(rs1);

            }


            stmt.close();
        } catch(SQLException se) { System.out.println(se); }


        return oneGroup;

    }
    
    public Group nestCheck(String id)
    {
        openConnection();

        try{
            String selectSQL = "SELECT * FROM Groups WHERE gName !=\"Unattached\" && type=\"NestGroup\" && houseID = \""+id+"\";";
            ResultSet rs1 = stmt.executeQuery(selectSQL);
            // Retrieve the results
            
            
            while(rs1.next()){
                oneGroup = getNextGroup(rs1);

            }


            stmt.close();
        } catch(SQLException se) { System.out.println(se); }


        return oneGroup;

    }
   
    public void connectLights(int newID, String type,String houseID)
    {
        openConnection();

        try{
            String selectSQL = "UPDATE Lights" +
                    " INNER JOIN Groups ON Lights.groupID = Groups.groupID " +
                    "SET Lights.groupID=" + newID +
                    " WHERE Lights.groupID=0 && Groups.type=\""+type+"\" && Groups.houseID=\""+houseID+"\" ;";
            stmt.executeUpdate(selectSQL);


            stmt.close();
        } catch(SQLException se) { System.out.println(se); }
    }
    
    public void connectNest(int newID, String type,String houseID)
    {
        openConnection();

        try{
            String selectSQL = "UPDATE Nest" +
                    " INNER JOIN Groups ON Nest.groupID = Groups.groupID " +
                    "SET Nest.groupID=" + newID +
                    " WHERE Nest.groupID=1 && Groups.type=\""+type+"\" && Groups.houseID=\""+houseID+"\" ;";
            stmt.executeUpdate(selectSQL);


            stmt.close();
        } catch(SQLException se) { System.out.println(se); }
    }


    public ArrayList<Group> findAllByHouse(String id)
    {
        openConnection();

        try{
            String selectSQL = "SELECT * FROM Groups WHERE houseID ="+id+";";
            ResultSet rs1 = stmt.executeQuery(selectSQL);
            // Retrieve the results

            while(rs1.next()){
                oneGroup = getNextGroup(rs1);

                list.add(oneGroup);

            }


            stmt.close();
        } catch(SQLException se) { System.out.println(se); }


        return list;


    }

    public Group insertGroup(Group insert) {

        System.out.println(insert);

        openConnection();
        oneGroup= null;


        try {
            System.out.println(insert.toSQL());
            String selectSQL = "insert into Groups VALUES("+insert.toSQL()+");";
            stmt.executeUpdate(selectSQL);
            //TODO need to set up a second sql statment

            System.out.println("Added to the database");

            stmt.close();
            closeConnection();
        } catch(SQLException se) { System.out.println(se); }


        return oneGroup;
    }


	
			
   
   
   
}
