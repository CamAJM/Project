BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS `lights` (
	`id`	VARCHAR UNIQUE,
	`type`	VARCHAR,
	`name`	VARCHAR,
	`modelid`	VARCHAR,
	`swversion`	VARCHAR,
	`on`	BOOLEAN,
	`bri`	INTEGER,
	`hue`	INTEGER,
	`sat`	INTEGER,
	`xy`	VARCHAR,
	`ct`	INTEGER,
	`alert`	VARCHAR,
	`effect`	VARCHAR,
	`colormode`	VARCHAR,
	`reachable`	BOOLEAN,
	PRIMARY KEY(`id`)
);
COMMIT;
