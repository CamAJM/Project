package com.example.a15077496.lab1;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import lights.HueDAO;
import lights.Lights;

public class LightGroups extends AppCompatActivity{

    private LinearLayout linearLayout;
    private int i;
    ArrayList<Lights> arrLight;


    @Override
    public void onCreate(final Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView(R.layout.dialog_group);
        StrictMode.ThreadPolicy policy =
                new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        Intent intent = getIntent();
        int id = intent.getIntExtra("id", 0);
        System.out.println("GroupID: "+ id);
        linearLayout = (LinearLayout) findViewById( R.id.groupsLayout );

        if(id==0) {
            // broken
        }
        else
        {
            arrLight = getLightsByGroup(id);
            System.out.println(arrLight);

            if(arrLight != null)
            {
                System.out.println("Size is: "+arrLight.size());
                for(i=0;i<arrLight.size();i++)
                {
                    TextView name = new TextView( this );
                    TextView status = new TextView( this );

                    name.setText( "Device number: " + arrLight.get( i ).getId() );
                    if(arrLight.get( i ).getOn().matches( "1" ))
                    {
                        status.setText( "Status: On" );
                    }
                    else
                    {
                        status.setText( "Status: Off" );
                    }


                    linearLayout.addView( name );
                    linearLayout.addView( status );



                }
            }
            else
            {
                System.out.println("No lights attached");
            }
        }




    }

    public int unLink(String id)
    {
        String serverURL = "http://10.0.2.2:8080/ProjectTesting/Unlink";

        URL url;
        HttpURLConnection conn;


        String fullURL;

        fullURL = serverURL + "?id="+id;


        fullURL = fullURL.replaceAll("%3D", "=")
                .replaceAll("%26", "&")
                // .replaceAll("%5B","[")
                //.replaceAll("%5D","]")
                .replaceAll("%2C", ",");

        int result = 503
                ;
        try {

            url = new URL(fullURL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");

            result = conn.getResponseCode();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }
    public ArrayList<Lights> getLightsByGroup(int id)
    {

        ArrayList<Lights> arrayList = null;

        HueDAO hueDAO = new HueDAO();

        arrayList = hueDAO.findAllByGroup( id );

        return arrayList;



    }
}
