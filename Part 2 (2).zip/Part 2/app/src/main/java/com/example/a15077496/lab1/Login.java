package com.example.a15077496.lab1;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.digest.DigestUtils;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class Login extends AppCompatActivity {

    String user;
    String pass;
    static String loginServerURL;
    AlertDialog alertDialog = null;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        StrictMode.ThreadPolicy policy =
                new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        // take username and password

        Button btnLogin = (Button) findViewById(R.id.btnLogin);
        alertDialog = new AlertDialog.Builder(Login.this).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage("Server is not reachable. This may be a temporary outage. Please try again later.");
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                TextView userIn = (EditText) findViewById(R.id.userIn);
                TextView passIn = (EditText) findViewById(R.id.passIn);

                // Code here executes on main thread after user presses button
                user = userIn.getText().toString();

                String password = passIn.getText().toString();

                pass = new String(Hex.encodeHex(DigestUtils.sha256( password )));


                loginServerURL = "http://10.0.2.2:8080/ProjectTesting/CheckLogin";
                int result = sendToServer();



                if (result == 200) {
                    alertDialog.setMessage("Login successful");
                    alertDialog.show();

                    alertDialog.setOnDismissListener(new Dialog.OnDismissListener() {
                        @Override
                        public void onDismiss(DialogInterface dialogInterface) {

                            Intent myIntent = new Intent(Login.this, MainActivity.class);
                            myIntent.putExtra("username", user); //Optional parameters
                            myIntent.putExtra("password", pass); //Optional parameters
                            Login.this.startActivity(myIntent);

                        }
                    });

                } else if (result == 401) {
                    alertDialog.setMessage("Your username or password is incorrect!");
                    alertDialog.show();
                } else
                {
                    alertDialog.setMessage("Something went wrong. If this issue continues, please contact" +
                            "an administrator.");
                    alertDialog.show();
                }

            }
        });


        TextView register = (TextView) findViewById(R.id.register);




        register.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(Login.this, Register.class);

                Login.this.startActivity(myIntent);
            }
        });

    }
    public int sendToServer() {



        URL url;
        HttpURLConnection conn;


        String fullURL;

        fullURL = loginServerURL + "?username=" + user +"&&password="+pass;


        fullURL = fullURL.replaceAll("%3D", "=")
                .replaceAll("%26", "&")
                // .replaceAll("%5B","[")
                //.replaceAll("%5D","]")
                .replaceAll("%2C", ",");

        int result = 0
                ;
        try {

            url = new URL(fullURL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");

            result = conn.getResponseCode();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;


    }
}