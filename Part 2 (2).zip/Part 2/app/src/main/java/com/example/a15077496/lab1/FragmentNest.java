package com.example.a15077496.lab1;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.gson.Gson;

import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import group.Group;
import user.User;

public class FragmentNest extends Fragment {

    View v;
    private String username;
    private String password;
    public static String sensorServerURL = "http://10.0.2.2:8080/ProjectTesting/";

    private RecyclerView myrecyclerview;
    ArrayList<Integer> all = new ArrayList<>();
    private List<Group> lstGroup=new ArrayList<>();
    public FragmentNest() {
    }
    AlertDialog alertDialog = null;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle saveInstanceState) {

        alertDialog = new AlertDialog.Builder(getActivity()).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage("Server error. This may be due to a temporary outage. Please try again later.");
        alertDialog.setButton(android.support.v7.app.AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });


        Bundle b = getArguments();
        if (b !=null) {
            // String username = bundle.getString("username");

            username = b.getString("username");
            password = b.getString("password");
        }else{
            alertDialog.show();
        }

        v = inflater.inflate(R.layout.nest_fragment, container, false);


        User user = getUser(username, password);
        findDevices(user);

        myrecyclerview = (RecyclerView) v.findViewById(R.id.group_recyclerview_nest);
        RecyclerViewAdapter recyclerAdapter = new RecyclerViewAdapter(getContext(), lstGroup);
        myrecyclerview.setLayoutManager(new LinearLayoutManager(getActivity()));
        myrecyclerview.setAdapter(recyclerAdapter);

        return v;
    }

    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);





    }

    public ArrayList<Group> getHouse(String houseID) {
        // gDAO.findAllByHouse(user.getHouseID());
        URL url;
        HttpURLConnection conn;
        BufferedReader rd;


        String fullURL;

        fullURL = sensorServerURL + "GetAllByHouse?id=" + houseID;


        fullURL = fullURL.replaceAll("%3D", "=")
                .replaceAll("%26", "&")
                // .replaceAll("%5B","[")
                //.replaceAll("%5D","]")
                .replaceAll("%2C", ",");

        String line;
        StringBuilder result = new StringBuilder();
        ArrayList<Group> arrGroup = new ArrayList<>();
        try {

            url = new URL(fullURL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            while ((line = rd.readLine()) != null) {
                result.append(line);

            }
            rd.close();

            JSONArray jsonArray = new JSONArray(result.toString());


            for (int i = 0; i < jsonArray.length(); i++) {
                Gson gson = new Gson();
                Group oneGroup = gson.fromJson(jsonArray.getString(i), Group.class);
                arrGroup.add(oneGroup);
            }


        } catch (Exception e) {
            e.printStackTrace();
        }

        return arrGroup;


    }

    //final ArrayList<Group> arrGroup = getHouse(user.getHouseID());
    public void findDevices(User user) {
        final ArrayList<Group> arrGroup = getHouse(user.getHouseID());

        //LinearLayout linearLayout = (LinearLayout) findViewById(R.id.linearlayout_id);
        //setContentView(linearLayout);

        if (arrGroup.size() > 0) {

            for (int i = 0; i < arrGroup.size(); i++) {
                Group oneGroup = arrGroup.get(i);

                if (!oneGroup.getgName().matches("Unattached")) {
                    // TextView textView = new TextView(this);
                    //textView.setText(oneGroup.toString());
                    //textView.setTextSize(30);
                    //linearLayout.addView(textView);


                    final int id = arrGroup.get(i).getGroupID();

                    if(!oneGroup.getType().matches("LightGroup")) {
                        all.add( (arrGroup.get( i )).getGroupID() );

                        lstGroup.add( arrGroup.get( i ) );

                    }




                } else {

                    System.out.println("help me");
                }

            }
        }
    }


    public User getUser(String username, String password)
    {
        URL url;
        HttpURLConnection conn;
        BufferedReader rd;

        String fullURL;

        fullURL = sensorServerURL + "GetUser?"+ URLEncoder.encode("username="+username+"&&password="+password);

        fullURL = fullURL.replaceAll("%3D", "=")
                .replaceAll("%26", "&")
                // .replaceAll("%5B","[")
                //.replaceAll("%5D","]")
                .replaceAll("%2C", ",");

        String line;
        StringBuilder result = new StringBuilder();
        User oneUser = null;

        try {

            url = new URL(fullURL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");


            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            while ((line = rd.readLine()) != null) {
                result.append(line);

            }
            rd.close();

            if(conn.getResponseCode()==200) {
                JSONArray jsonArray = new JSONArray(result.toString());


                for (int i = 0; i < jsonArray.length(); i++) {
                    Gson gson = new Gson();
                    oneUser = gson.fromJson(jsonArray.getString(i), User.class);
                }
            }
            else
            {
                oneUser = null;
            }


        } catch (Exception e) {
            e.printStackTrace();
        }

        return oneUser;

    }


    public void restart(){
        getFragmentManager().beginTransaction().detach(this).attach(this).commit();

    }
}
