package com.example.a15077496.lab1;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import group.Group;
import lights.HueDAO;
import lights.Lights;


public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder> {



    Context mContext;
    private RecyclerView myrecyclerview;
    List<Group> mData;
    Dialog myDialog;
    private static String sensorServerURL = "http://10.0.2.2:8080/ProjectTesting/";
    View v,j;


    public RecyclerViewAdapter(Context mContext,List<Group> mData){
        this.mContext = mContext;
        this.mData = mData;
    }

    @Override
    public MyViewHolder onCreateViewHolder(final ViewGroup parent, int viewType) {



        v = LayoutInflater.from(mContext).inflate(R.layout.item_hue,parent,false);
        final MyViewHolder vHolder = new MyViewHolder(v);

        myDialog = new Dialog(mContext);
        myDialog.setContentView( R.layout.dialog_hue );


        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        vHolder.item_hue.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                if(mData.get(vHolder.getAdapterPosition()).getType().matches( "LightGroup" ))
                {

                    TextView dialog_name_tv =(TextView) myDialog.findViewById(R.id.dialog_name_id);
                    TextView dialog_type_tv =(TextView) myDialog.findViewById(R.id.dialog_type_id);
                    TextView dialog_status_tv =(TextView) myDialog.findViewById(R.id.dialog_status_id);
                    View dialog_btn_status = myDialog.findViewById(R.id.dialog_btn_status);
                    View dialog_view_lights = myDialog.findViewById( R.id.dialog_btn_view );

                    dialog_name_tv.setText(mData.get(vHolder.getAdapterPosition()).getgName());
                    dialog_type_tv.setText(mData.get(vHolder.getAdapterPosition()).getType());
                    dialog_status_tv.setText(mData.get(vHolder.getAdapterPosition()).getStatus());
                    Toast.makeText(mContext, "Clicked" + String.valueOf(vHolder.getAdapterPosition()), Toast.LENGTH_SHORT).show();
                    myDialog.show();

                    dialog_view_lights.setOnClickListener( new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            Context c = view.getContext();
                            Intent myIntent = new Intent(c, LightGroups.class);
                            myIntent.putExtra("id", mData.get(vHolder.getAdapterPosition()).getGroupID()); //Optional parameters
                            mContext.startActivity(myIntent);



                        }
                    });

                    dialog_btn_status.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            int groupID = mData.get(vHolder.getAdapterPosition()).getGroupID();
                            int statIn = Integer.parseInt(mData.get(vHolder.getAdapterPosition()).getStatus());
                            int status = 0;

                            AlertDialog.Builder alertDialog = new AlertDialog.Builder(mContext);
                            alertDialog.setTitle("Alert");
                            alertDialog.setMessage("your message ");
                            alertDialog.setPositiveButton("CANCEL", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.cancel();
                                }
                            });

                            if(statIn == 1)
                            {
                                status = 0;
                                mData.get(vHolder.getAdapterPosition()).setStatus("0");
                            }
                            else if (statIn == 0)
                            {
                                status = 1;
                                mData.get(vHolder.getAdapterPosition()).setStatus("1");

                            }
                            else
                            {
                            }

                            int result = sendToServer(status, groupID);

                            switch(result)
                            {
                                case 200:
                                    MainActivity ma = new MainActivity();

                                    //RecyclerViewAdapter rva;
                                    //rva = getActivity().findViewById(R.id.linearlayout_id);
                                    myDialog.dismiss();
                                    ma.Restart(mContext);
                                    break;
                                case 500:
                                    alertDialog.setMessage("Internal Server Error");
                                    alertDialog.show();
                                    break;
                                case 401:

                                    System.out.println("This group does not have any lights attached to it!");
                                    alertDialog.setMessage("This group does not have any lights attached to it!");
                                    alertDialog.show();
                                    break;

                            }


                        }

                    });



                }
                else
                {
                    myDialog.setContentView( R.layout.dialog_nest );
                    TextView dialog_name_tv =(TextView) myDialog.findViewById(R.id.dialog_name_id);
                    TextView dialog_type_tv =(TextView) myDialog.findViewById(R.id.dialog_type_id);
                    TextView dialog_status_tv =(TextView) myDialog.findViewById(R.id.dialog_status_id);
                    final EditText dialog_temp_change = (EditText) myDialog.findViewById( R.id.dialog_temp_change );
                    View dialog_btn_temp = myDialog.findViewById( R.id.dialog_btn_temp );

                    dialog_name_tv.setText(mData.get(vHolder.getAdapterPosition()).getgName());
                    dialog_type_tv.setText(mData.get(vHolder.getAdapterPosition()).getType());
                    dialog_status_tv.setText(mData.get(vHolder.getAdapterPosition()).getStatus());
                    Toast.makeText(mContext, "Clicked" + String.valueOf(vHolder.getAdapterPosition()), Toast.LENGTH_SHORT).show();
                    myDialog.show();

                    dialog_btn_temp.setOnClickListener( new View.OnClickListener() {

                        @Override
                        public void onClick(View view) {
                            int groupID = mData.get(vHolder.getAdapterPosition()).getGroupID();
                            int status = Integer.parseInt(dialog_temp_change.getText().toString());

                            AlertDialog.Builder alertDialog = new AlertDialog.Builder(mContext);
                            alertDialog.setTitle("Error");
                            alertDialog.setMessage("your message ");
                            alertDialog.setPositiveButton("CANCEL", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.cancel();
                                }
                            });

                            if(status == 0)
                            {
                                alertDialog.setMessage( "Temperature has not been set." +
                                        " Value must be between 10 and 30" );
                                alertDialog.show();
                            }
                            else if (status <10)
                            {
                                final String degree = "\u00b0"+"C";
                                // Porridge is to cold
                                alertDialog.setMessage( "Temperature cannot be less than 10.\n" +
                                        "\nDid you know that the recommended minimum temperature is 18"+ degree+"?" );
                                alertDialog.show();
                            }
                            else if (status >30)
                            {
                                final String degree = "\u00b0"+"C";
                                // Porridge is to hot
                                alertDialog.setMessage( "Temperature cannot be higher than 30.\n" +
                                        "\nDid you know that the recommended minimum temperature is 18"+ degree+"?" );

                                alertDialog.show();
                            }
                            else
                            {
                                // Goldilocks zone
                                int result = changeTemp(status, groupID);

                                switch(result)
                                {
                                    case 200:
                                        MainActivity ma = new MainActivity();

                                        //RecyclerViewAdapter rva;
                                        //rva = getActivity().findViewById(R.id.linearlayout_id);
                                        myDialog.dismiss();
                                        ma.Restart(mContext);
                                        break;
                                    case 500:
                                        alertDialog.setMessage("Internal Server Error");
                                        alertDialog.show();
                                        break;
                                    case 401:

                                        System.out.println("This group does not have any nest devices attached to it!");
                                        alertDialog.setMessage("This group does not have any Nest devices attached to it!");
                                        alertDialog.show();
                                        break;

                                }
                            }




                        }

                    });
                }


            }
        });

        return vHolder;


    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        holder.tv_name.setText(mData.get(position).getgName());
        holder.tv_type.setText(mData.get(position).getType());
        holder.tv_status.setText(mData.get(position).getStatus());

    }

    @Override
    public int getItemCount() {
        return mData.size();
    }


    public static class MyViewHolder extends RecyclerView.ViewHolder{

        private LinearLayout item_hue;
        private TextView tv_name;
        private TextView tv_type;
        private TextView tv_status;





        public MyViewHolder(View itemView){
            super(itemView);
            item_hue = (LinearLayout) itemView.findViewById(R.id.group_item_id);
            tv_name = (TextView) itemView.findViewById(R.id.name_group);
            tv_type = (TextView) itemView.findViewById(R.id.light_type);
            tv_status = (TextView) itemView.findViewById(R.id.light_status);
        }


    }
    public int changeTemp(int status, int groupID)
    {
        int result = 500;
        URL url;
        HttpURLConnection conn;

        String fullURL;

        fullURL = sensorServerURL + "ChangeTemp?id="+groupID+"&&status="+status;

        System.out.println(fullURL);

        try{
            url = new URL(fullURL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod( "POST" );

            result = conn.getResponseCode();


        }catch(Exception e)
        {
            e.printStackTrace();
        }
        return result;
    }

    // method to send data to server
    public int sendToServer(int status, int groupID) {

        int result = 500;
        URL url;
        HttpURLConnection conn;
        if (status == 1) {
            // go to on servlet

            String fullURL;

            fullURL = sensorServerURL + "turnOn?id=" + groupID;

            try {

                url = new URL(fullURL);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");

                result = conn.getResponseCode();

            } catch (Exception e) {
                e.printStackTrace();
            }

        } else if (status == 0) {
            // go to off servlet
            String fullURL;

            fullURL = sensorServerURL + "turnOff?id=" + groupID;


            fullURL = fullURL.replaceAll("%3D", "=")
                    .replaceAll("%26", "&")
                    // .replaceAll("%5B","[")
                    //.replaceAll("%5D","]")
                    .replaceAll("%2C", ",");

            System.out.println("FULLURL: " + fullURL);


            try {

                url = new URL(fullURL);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");

                System.out.println("CODE: "+conn.getResponseCode());
                result = conn.getResponseCode();


            } catch (Exception e) {
                e.printStackTrace();
            }

        } else {
            result = 500;
        }

        return result;

    }



}