package com.example.a15077496.lab1;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.net.HttpURLConnection;
import java.net.URL;


public class NewGroup extends AppCompatActivity {
    private String type;
    private AlertDialog alertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_group);
        Intent intent = getIntent();
        final String houseID = intent.getStringExtra("house");



        alertDialog = new AlertDialog.Builder(NewGroup.this).create();
        alertDialog.setTitle("Alert");
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        Spinner dropdown = (Spinner) findViewById(R.id.spinner4);

        String[] items = new String[]{"Select a group type","LightGroup","NestGroup"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);

        dropdown.setAdapter(adapter);

        dropdown.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {



                switch (i)
                {
                    case 0:
                        break;
                    case 1:
                        type = adapterView.getItemAtPosition(1).toString();
                        break;
                    case 2:
                        type = adapterView.getItemAtPosition(2).toString();
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                type = adapterView.getItemAtPosition(1).toString();

            }





        });
        Button group = (Button) findViewById(R.id.btnGroup);

        group.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                TextView nameIn = (EditText) findViewById(R.id.gNameIn);
                String gName = nameIn.getText().toString();


                int code = toServer(gName, type, houseID);

                switch(code)
                {
                    case 200:

                        alertDialog.setMessage("Group has been created!");
                        alertDialog.show();

                        break;
                    case 422:

                        alertDialog.setMessage("Ensure that a name and type have been selected!");
                        alertDialog.show();

                        break;
                    case 500:

                        alertDialog.setMessage("Server error. If this error continues, please" +
                                " contact an administrator");
                        alertDialog.show();

                        break;
                    case 401:

                        alertDialog.setMessage("Group already exists!");
                        alertDialog.show();

                        break;
                    case 404:

                        alertDialog.setMessage("Server error. If this error continues, please contact" +
                                " an administrator.");
                        alertDialog.show();

                        break;
                }


            }
        });


    }
    public int toServer(String gName, String type, String houseID)
    {
        // gDAO.findAllByHouse(user.getHouseID());
        URL url;
        HttpURLConnection conn;
        String serverURL = "http://10.0.2.2:8080/ProjectTesting/NewGroup";

        String fullURL;

        fullURL = serverURL + "?gName=" + gName + "&&type="+type+"&&houseID="+houseID;


        fullURL = fullURL.replaceAll("%3D", "=")
                .replaceAll("%26", "&")
                // .replaceAll("%5B","[")
                //.replaceAll("%5D","]")
                .replaceAll("%2C", ",");


        int result = 0;
        try {

            url = new URL(fullURL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");

            result = conn.getResponseCode();


        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;


    }
}