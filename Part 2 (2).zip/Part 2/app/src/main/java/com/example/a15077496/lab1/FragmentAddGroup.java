package com.example.a15077496.lab1;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.gson.Gson;

import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import user.User;



public class FragmentAddGroup extends Fragment {

    private int code;
    User oneUser = null;
    public static String sensorServerURL = "http://10.0.2.2:8080/ProjectTesting/";
    private String type;
    private String username;
    private String password;
    private View rootView;
    private AlertDialog alertDialog;

    public FragmentAddGroup() {
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle saveInstanceState) {

        alertDialog = new AlertDialog.Builder(getActivity()).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage("Server error. This may be due to a temporary outage. Please try again later.");
        alertDialog.setButton(android.support.v7.app.AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        Bundle b = getArguments();
        if (b !=null) {
            // String username = bundle.getString("username");

            username = b.getString("username");
            password = b.getString("password");
        }else{
            alertDialog.setMessage( "Internal error. Please try logging out and back in again." );
            alertDialog.show();
        }

        oneUser = getUser( username, password );



        rootView = inflater.inflate(R.layout.activity_new_group,container,false);



        Button group = (Button) rootView.findViewById( R.id.btnGroup );

        group.setOnClickListener( new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                TextView typeIn = (TextView) rootView.findViewById( R.id.gTypeIn );

                type = typeIn.getText().toString();


                if(type.matches( "LightGroup" )|| type.matches( "NestGroup" ))
                {
                    TextView nameIn = (EditText) rootView.findViewById( R.id.gNameIn );
                    String gName = nameIn.getText().toString();
                    String houseID = oneUser.getHouseID();

                    int code = toServer( gName, type, houseID );


                    switch (code) {
                        case 200:

                            alertDialog.setMessage( "Group has been created!" );
                            alertDialog.show();

                            break;
                        case 422:

                            alertDialog.setMessage( "Ensure that a name and type have been selected!" );
                            alertDialog.show();

                            break;
                        case 500:

                            alertDialog.setMessage( "Server error. If this error continues, please" +
                                    " contact an administrator" );
                            alertDialog.show();

                            break;
                        case 401:

                            alertDialog.setMessage( "Group already exists!" );
                            alertDialog.show();

                            break;
                        case 404:

                            alertDialog.setMessage( "Server error. If this error continues, please contact" +
                                    " an administrator." );
                            alertDialog.show();

                            break;
                    }
                }
                else
                {
                    alertDialog.setMessage( "Invalid group. \n" +
                            "Currently supported groups are: LightGroup or NestGroup" );
                    alertDialog.show();

                }






            }
        } );

        return rootView;
    }


    public int toServer(String gName, String type, String houseID)
    {
        URL url;
        HttpURLConnection conn;

        String fullURL;

        fullURL = sensorServerURL + "NewGroup?gName=" + gName + "&&type="+type+"&&houseID="+houseID;


        fullURL = fullURL.replaceAll("%3D", "=")
                .replaceAll("%26", "&")
                // .replaceAll("%5B","[")
                //.replaceAll("%5D","]")
                .replaceAll("%2C", ",");


        int result = 0;
        try {

            url = new URL(fullURL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");

            result = conn.getResponseCode();


        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;


    }
    public User getUser(String username, String password)
    {
        URL url;
        HttpURLConnection conn;
        BufferedReader rd;

        String fullURL;

        fullURL = sensorServerURL + "GetUser?"+ URLEncoder.encode("username="+username+"&&password="+password);

        fullURL = fullURL.replaceAll("%3D", "=")
                .replaceAll("%26", "&")
                // .replaceAll("%5B","[")
                //.replaceAll("%5D","]")
                .replaceAll("%2C", ",");

        String line;
        StringBuilder result = new StringBuilder();
        User oneUser = null;

        try {

            url = new URL(fullURL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");


            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            while ((line = rd.readLine()) != null) {
                result.append(line);

            }
            rd.close();

            code = conn.getResponseCode();


            JSONArray jsonArray = new JSONArray(result.toString());


            for (int i = 0; i < jsonArray.length(); i++) {
                Gson gson = new Gson();
                oneUser = gson.fromJson(jsonArray.getString(i), User.class);
            }


        } catch (Exception e) {
            e.printStackTrace();
        }

        return oneUser;

    }


}
