package com.example.a15077496.lab1;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import group.Group;
import group.GroupDAO;

public class NewGroup extends AppCompatActivity {
    private String type;
    private AlertDialog alertDialog;
    Group newGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_group);
        Intent intent = getIntent();
        final String houseID = intent.getStringExtra("house");



        alertDialog = new AlertDialog.Builder(NewGroup.this).create();
        alertDialog.setTitle("Alert");
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        Spinner dropdown = (Spinner) findViewById(R.id.spinner4);

        String[] items = new String[]{"Select a group type","LightGroup","NestGroup"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);

        dropdown.setAdapter(adapter);

        dropdown.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {



                switch (i)
                {
                    case 0:
                        break;
                    case 1:
                        type = adapterView.getItemAtPosition(1).toString();
                        break;
                    case 2:
                        type = adapterView.getItemAtPosition(2).toString();
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                type = adapterView.getItemAtPosition(1).toString();

            }





        });
        Button group = (Button) findViewById(R.id.btnGroup);

        group.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                TextView nameIn = (EditText) findViewById(R.id.gNameIn);
                String gName = nameIn.getText().toString();

                GroupDAO dao = new GroupDAO();

                if(dao.searchGroups(gName, houseID)==null)
                {

                    int latest = dao.getLatest();

                    latest = latest+1;
                    newGroup = new Group(latest,gName,type,houseID);

                    if(gName != null&&type!= null&&houseID!= null)
                    {
                        dao.insertGroup(newGroup);
                        alertDialog.setMessage("Group has been created!");
                        alertDialog.show();
                    }
                    else
                    {
                        alertDialog.setMessage("Ensure name and type are selected. If this error continues" +
                                ", please contact an administrator.");
                        alertDialog.show();
                    }
                }
                else
                {
                    alertDialog.setMessage("This group already exists!");
                    alertDialog.show();
                }


            }
        });


    }
}
