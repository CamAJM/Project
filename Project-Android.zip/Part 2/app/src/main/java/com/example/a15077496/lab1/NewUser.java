package com.example.a15077496.lab1;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import user.User;
import user.UserDAO;

public class NewUser extends AppCompatActivity {
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newuser);
        StrictMode.ThreadPolicy policy =
                new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        Intent intent = getIntent();
        final String house = intent.getStringExtra("house");

        System.out.println("HELLO. ID IS: "+ house);
        Button register = (Button) findViewById(R.id.btnRegister);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView userIn = (EditText) findViewById(R.id.userIn);
                TextView passIn = (EditText) findViewById(R.id.passIn);

                String username = userIn.getText().toString();
                String password = passIn.getText().toString();
                UserDAO dao = new UserDAO();

                AlertDialog alertDialog = new AlertDialog.Builder(NewUser.this).create();
                alertDialog.setTitle("Alert");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });

                if(dao.getUser(username, password)== null)
                {
                    alertDialog.setMessage("User has been created!");
                    alertDialog.show();

                    User user = new User(username,password,house,null);
                    dao.insertUser(user);

                }
                else
                {
                    alertDialog.setMessage("User already exists!");
                    alertDialog.show();

                }

                // Check if exists

                // if not, add user

                // else throw error

                // submit button


            }
        });




    }
}
