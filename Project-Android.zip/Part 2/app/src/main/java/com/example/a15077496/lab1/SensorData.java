package com.example.a15077496.lab1;

/**
 * Created by 15077496 on 01/12/2017.
 */

public class SensorData {

    String UserId;
    String SensorName;
    String SensorValue;

    public SensorData(){

    }

    public SensorData(String userId, String sensorName, String sensorValue) {
        super();
        this.UserId = userId;
        this.SensorName = sensorName;
        this.SensorValue = sensorValue;
    }

    public String getUserId() {return UserId;}
    public void setUserId(String userId) {
        UserId = userId;
    }
    public String getSensorName() {
        return SensorName;
    }
    public void setSensorName(String sensorName) {
        SensorName = sensorName;
    }
    public String getSensorValue() {
        return SensorValue;
    }
    public void setSensorValue(String sensorValue) {
        SensorValue = sensorValue;
    }





    @Override
    public String toString() {
        return "SensorData [UserId=" + UserId + ", SensorName=" + SensorName + ", SensorValue=" + SensorValue + "]";
    }
}




