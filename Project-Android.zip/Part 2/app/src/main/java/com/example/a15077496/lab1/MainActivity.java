package com.example.a15077496.lab1;

import android.content.DialogInterface;
import android.os.StrictMode;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;

import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

import dao.UserDAO;
import user.User;

public class MainActivity extends AppCompatActivity {

    private Button retrieveButton;
     private Button SendButton;
    private Switch SwitchButton;
    private EditText SendTexts;
    public TextView RetrieveTextView;
    private Spinner SendListView;


    Statement stmt;
    public static String sensorServerURL = "http://10.0.2.2:8080/ProjectTesting/HueServ";

    @Override

    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        StrictMode.ThreadPolicy policy =
                new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        SwitchButton = (Switch) findViewById(R.id.SendSwitch);


    // switch  on button
        SwitchButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {

                    //SensorData mySensor = new SensorData(UserID, "Light", "on");
                    light mylight= new light("1","Extended color light","Hue Lamp 1","LCT001","66009461","true","144","13088","212","[0.5128,0.4147]","467","none","none","xy","true" );
                    //Gson gson = new Gson();
                    //String jsonString = gson.toJson(mylight);

                    String jsonString = mylight.toString();
                    sendToServer(jsonString);
                    Toast.makeText(getApplicationContext(),
                            "Switch is on", Toast.LENGTH_LONG).show();
                }
                // switch off button
                else {
                    light mylight= new light("1","Extended color light","Hue Lamp 1","LCT001","66009461","false","144","13088","212","[0.5128,0.4147]","467","none","none","xy","true");

                    String jsonString = mylight.toString();
                    sendToServer(jsonString);

                    Toast.makeText(getApplicationContext(),
                            "Switch is off", Toast.LENGTH_LONG).show();
                }

            }
        });
        // array for drop down selection

/*
// retrieve button
        retrieveButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String sensorResult = getSensorData("motor");
                Gson gson = new Gson();
                SensorData s = gson.fromJson(sensorResult,SensorData.class);
        RetrieveTextView.setText(String.format("ID: %s SensorName: %s SensorValue: %s ",s.getUserId(),s.getSensorName(),s.getSensorValue()));
            }

        });
        // send button
        SendButton.setOnClickListener(new View.OnClickListener() {
           public void onClick(View v) {
               String sending = SendTexts.getText().toString();
               String selected = SendListView.getSelectedItem().toString();
               SensorData mySensor = new SensorData(UserID,selected,sending);
               Gson gson = new Gson();
               String jsonString = gson.toJson(mySensor);
               Log.i(TAG,jsonString);
               sendToServer(jsonString);
               Log.i(TAG, "Sending" +selected+ " "+ sending);

            }

       });
       */
    }

/*
// method to get data from server which retrieves from the database
    private String getSensorData(String sensorvalue) {
        Log.i(TAG, "retrieving data");
        URL url;
        HttpURLConnection conn;
        BufferedReader rd;
        String fullURL = sensorServerURL + "?getdata=true&sensorname=" + sensorvalue;
        Log.i(TAG, "Sending request for sensor data to:" + fullURL);
        String line = "";
        String result = "";

        try {
            url = new URL(fullURL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            while ((line = rd.readLine()) != null) {
                result += line;
            }
            rd.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
    */

// method to send data to server
    public String sendToServer(String SensorData){

        UserDAO dao = new UserDAO();
        User user;

        user = dao.getUsers("");

        AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage("Server is not reachable. This may be a temporary outage. Please try again later.");
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        URL url;
        HttpURLConnection conn;
        BufferedReader rd;


        String fullURL = null;

        fullURL = sensorServerURL + "?" +URLEncoder.encode(SensorData);


        fullURL = fullURL.replaceAll("%3D", "=")
        .replaceAll("%26", "&")
       // .replaceAll("%5B","[")
        //.replaceAll("%5D","]")
        .replaceAll("%2C",",");




        System.out.println("Sending data to: "+fullURL);
        String line;
        String result = "";
        try {

            url = new URL(fullURL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            while ((line = rd.readLine()) != null) {
                result += line;
            }
            rd.close();
        } catch (Exception e) {
            e.printStackTrace();
            alertDialog.show();
        }
        return result;

    }
}



