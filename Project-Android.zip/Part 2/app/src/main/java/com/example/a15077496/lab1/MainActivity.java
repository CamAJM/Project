package com.example.a15077496.lab1;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import group.Group;
import user.User;
import user.UserDAO;

public class MainActivity extends AppCompatActivity {

    // private Switch SwitchButton;
    ArrayList<Integer> all = new ArrayList<>();
    UserDAO uDAO = new UserDAO();


    public static String sensorServerURL = "http://10.0.2.2:8080/ProjectTesting/";

    @Override

    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        StrictMode.ThreadPolicy policy =
                new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        Intent intent = getIntent();
        String username = intent.getStringExtra("username");
        String password = intent.getStringExtra("password");

        final User user = uDAO.getUser(username,password);

        findDevices(user);

        Spinner dropdown = (Spinner) findViewById(R.id.spinner);

        String[] items = new String[]{"+","New User", "New Group"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);

        dropdown.setAdapter(adapter);

        dropdown.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i)
                {
                    case 0:
                        break;
                    case 1:

                        Intent myIntent = new Intent(MainActivity.this, NewUser.class);
                        myIntent.putExtra("house",user.getHouseID());
                        MainActivity.this.startActivity(myIntent);

                        break;
                    case 2:

                        myIntent = new Intent(MainActivity.this, NewGroup.class);
                        myIntent.putExtra("house",user.getHouseID());
                        System.out.println("ID AT THIS POINT IS:" + user.getHouseID());
                        MainActivity.this.startActivity(myIntent);

                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });



    }
    public ArrayList<Group> getHouse(String houseID)
    {
        // gDAO.findAllByHouse(user.getHouseID());
        URL url;
        HttpURLConnection conn;
        BufferedReader rd;


        String fullURL;

        fullURL = sensorServerURL + "GetAllByHouse?id=" + houseID;


        fullURL = fullURL.replaceAll("%3D", "=")
                .replaceAll("%26", "&")
                // .replaceAll("%5B","[")
                //.replaceAll("%5D","]")
                .replaceAll("%2C", ",");

        System.out.println("Sending data to: " + fullURL);
        String line;
        StringBuilder result = new StringBuilder();
        ArrayList<Group> arrGroup = new ArrayList<>();
        try {

            url = new URL(fullURL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            while ((line = rd.readLine()) != null) {
                result.append(line);

            }
            rd.close();

            JSONArray jsonArray = new JSONArray(result.toString());


            for(int i=0; i<jsonArray.length();i++)
            {
                System.out.println(jsonArray.getString(i));
                Gson gson = new Gson();
                Group oneGroup = gson.fromJson(jsonArray.getString(i), Group.class);
                arrGroup.add(oneGroup);
            }


        } catch (Exception e) {
            e.printStackTrace();
        }

        return arrGroup;


    }

    public void findDevices(User user)
    {
        final ArrayList<Group> arrGroup = getHouse(user.getHouseID());

        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.MainWindow);
        setContentView(linearLayout);

        if(arrGroup.size() > 0) {

            for (int i = 0; i < arrGroup.size(); i++) {
                Group oneGroup = arrGroup.get(i);
                if (!oneGroup.getgName().matches("Unattached")) {
                    TextView textView = new TextView(this);
                    textView.setText(oneGroup.toString());
                    textView.setTextSize(30);
                    linearLayout.addView(textView);

                    final int id = arrGroup.get(i).getGroupID();

                    all.add((arrGroup.get(i)).getGroupID());

                    Switch SwitchButton = new Switch(this);

                    linearLayout.addView(SwitchButton);

                    // switch  on button
                    SwitchButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                        @Override
                        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                            if (isChecked) {

                                // Send to update servlet.
                                sendToServer(1, id);
                                Toast.makeText(getApplicationContext(),
                                        "Switch is on", Toast.LENGTH_LONG).show();
                            }
                            // switch off button
                            else {

                                sendToServer(0, id);

                                Toast.makeText(getApplicationContext(),
                                        "Switch is off", Toast.LENGTH_LONG).show();
                            }

                        }
                    });

                }
            }





        }
        else
        {


            TextView textView = new TextView(this);
            String text = "You don't have any devices!";
            textView.setText(text);
            textView.setTextSize(20);
            linearLayout.addView(textView);
        }

        Button btnLogout = new Button(this);
        String text = "Logout";
        btnLogout.setText(text);
        linearLayout.addView(btnLogout);


        btnLogout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                Intent myIntent = new Intent(MainActivity.this, Login.class);
                MainActivity.this.startActivity(myIntent);


            }
        });



    }

    // method to send data to server
    public void sendToServer(int status, int groupID) {

        AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage("Server is not reachable. This may be a temporary outage. Please try again later.");
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        URL url;
        HttpURLConnection conn;
        BufferedReader rd;

        if (status == 1) {
            // go to on servlet

            String fullURL;

            fullURL = sensorServerURL + "turnOn?id=" + groupID;


            fullURL = fullURL.replaceAll("%3D", "=")
                    .replaceAll("%26", "&")
                    // .replaceAll("%5B","[")
                    //.replaceAll("%5D","]")
                    .replaceAll("%2C", ",");

            System.out.println("Sending data to: " + fullURL);
            String line;
            try {

                url = new URL(fullURL);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");

            } catch (Exception e) {
                e.printStackTrace();
                alertDialog.show();
            }

        } else if (status == 0) {
            // go to off servlet
            String fullURL = null;

            fullURL = sensorServerURL + "turnOff?id=" + groupID;


            fullURL = fullURL.replaceAll("%3D", "=")
                    .replaceAll("%26", "&")
                    // .replaceAll("%5B","[")
                    //.replaceAll("%5D","]")
                    .replaceAll("%2C", ",");

            System.out.println("Sending data to: " + fullURL);

            try {

                url = new URL(fullURL);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));

            } catch (Exception e) {
                e.printStackTrace();
                alertDialog.show();
            }

        } else {
            System.out.println("Something went wrong.");
            String result = "error";
        }



    }
}


