package com.example.a15077496.lab1;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import user.UserDAO;

public class Login extends AppCompatActivity {
    @Override

    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        StrictMode.ThreadPolicy policy =
                new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        // take username and password

        Button btnLogin = (Button) findViewById(R.id.btnLogin);


        btnLogin.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                TextView userIn = (EditText) findViewById(R.id.userIn);
                TextView passIn = (EditText) findViewById(R.id.passIn);

                // Code here executes on main thread after user presses button
                String user = userIn.getText().toString();

                String password = passIn.getText().toString();

                UserDAO dao = new UserDAO();


                if (dao.getUser(user, password) != null) {
                    Intent myIntent = new Intent(Login.this, MainActivity.class);
                    myIntent.putExtra("username", user); //Optional parameters
                    myIntent.putExtra("password", password); //Optional parameters
                    Login.this.startActivity(myIntent);
                } else {
                    System.out.println("User not found.");
                }
            }
        });


        TextView register = (TextView) findViewById(R.id.register);




        register.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(Login.this, Register.class);

                Login.this.startActivity(myIntent);
            }
        });

    }
}
