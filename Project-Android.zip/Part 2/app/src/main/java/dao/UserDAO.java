package dao;


import java.util.ArrayList;
import java.sql.*;

import user.User;


public class UserDAO {

    ArrayList<User> list = new ArrayList<User>();
    User oneUser = null;
    Connection conn = null;
    Statement stmt = null;

    public UserDAO() {}


    public void openConnection(){
        // loading jdbc driver for mysql
        try{
            Class.forName("com.mysql.jdbc.Driver").newInstance();
        } catch(Exception e) { System.out.println(e); }

        // connecting to database
        try{
            // connection string for demos database, username demos, password demos
            // connect to cloud server for SQL database here
            conn = DriverManager.getConnection
                    ("jdbc:mysql://mudfoot.doc.stu.mmu.ac.uk:3306/whitej?user=whitej&password=Uclefask3");
            //  ("jdbc:sqlite:films.sqlite");
            stmt = conn.createStatement();
        } catch(SQLException se) { System.out.println(se); }
    }
    private void closeConnection(){
        try {
            conn.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    private User getNextUser(ResultSet rs){
        User thisUser=null;
        try {
            thisUser = new User(
                    rs.getString("username"),
                    rs.getString("password"),
                    rs.getString("houseID"),
                    rs.getString("cost"));
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return thisUser;
    }



	/*
   public ArrayList<Lights> getAllFilms(){

		ArrayList<Lights> allFilms = new ArrayList<Lights>();
		openConnection();

	    // Create select statement and execute it
		try{
		    String selectSQL = "select * from films";
		    ResultSet rs1 = stmt.executeQuery(selectSQL);
		    System.out.print(rs1);
	    // Retrieve the results
		    while(rs1.next()){
		    	oneLight = getNextFilm(rs1);
		    	allFilms.add(oneLight);
		   }

		    stmt.close();
		    closeConnection();
		} catch(SQLException se) { System.out.println(se); }

	   return allFilms;
   }
    */
   public User getUsers(String username){

		openConnection();

	    // Create select statement and execute it
		try{
		    String selectSQL = "select * from Users where username="+username;
		    ResultSet rs1 = stmt.executeQuery(selectSQL);
	    // Retrieve the results
		    while(rs1.next()){
		    	oneUser = getNextUser(rs1);
		    }

		    stmt.close();
		    closeConnection();
		} catch(SQLException se) { System.out.println(se); }

	   return oneUser;
   }


    public User insertUser(User insert) {

        openConnection();
        oneUser= null;


        try {
            String selectSQL = "insert into Users VALUES("+insert.toString()+");";
            stmt.executeUpdate(selectSQL);
            //TODO need to set up a second sql statment

            System.out.println("Added to the database");

            stmt.close();
            closeConnection();
        } catch(SQLException se) { System.out.println(se); }


        return oneUser;
    }




}
