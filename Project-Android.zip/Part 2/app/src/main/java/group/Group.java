package group;

public class Group {


    int groupID;
    String gName;
    String type;
    String houseID;


    public Group(int groupID, String gName, String type, String houseID) {
        this.groupID = groupID;
        this.gName = gName;
        this.type = type;
        this.houseID = houseID;
    }


    public int getGroupID() {
        return groupID;
    }

    public void setGroupID(int groupID) {
        this.groupID = groupID;
    }

    public String getgName() {
        return gName;
    }

    public void setgName(String gName) {
        this.gName = gName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getHouseID() {
        return houseID;
    }

    public void setHouseID(String houseID) {
        this.houseID = houseID;
    }

    public String toString() {
        String s = getgName();

        return s;
    }

    public String toSQL() {
        String s = getGroupID() + "," + "\"" + getgName() + "\",\"" + getType() + "\",\"" + getHouseID() + "\"";
        return s;
    }
}
