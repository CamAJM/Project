package lights;

/**
 * Created by Joe on 09/02/2018.
 */

public class Light {

    String Id;
    String type;
    String name;
    String modelid;
    String swversion;
    String on;
    String bri;
    String hue;
    String sat;
    String xy;
    String ct;
    String alert;
    String effect;
    String colormode;
    String reachable;
    String groupID;
    String houseID;


    public Light(String Id, String type ,String name ,String modelid, String swversion,String on,
            String bri, String hue, String sat, String xy ,String ct, String alert, String effect,
                 String colormode,String reachable, String groupID, String houseID) {
        super();
        this.Id = Id;
        this.type = type;
        this.name = name;
        this.modelid = modelid;
        this.swversion = swversion;
        this.on = on;
        this.bri = bri;
        this.hue = hue;
        this.sat = sat;
        this.xy = xy;
        this.ct = ct;
        this.alert = alert;
        this.effect = effect;
        this.colormode = colormode;
        this.reachable = reachable;
        this.groupID = groupID;
        this.houseID = houseID;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getModelid() {
        return modelid;
    }

    public void setModelid(String modelid) {
        this.modelid = modelid;
    }

    public String getSwversion() {
        return swversion;
    }

    public void setSwversion(String swversion) {
        this.swversion = swversion;
    }

    public String getOn() {
        return on;
    }

    public void setOn(String on) {
        this.on = on;
    }

    public String getBri() {
        return bri;
    }

    public void setBri(String bri) {
        this.bri = bri;
    }

    public String getHue() {
        return hue;
    }

    public void setHue(String hue) {
        this.hue = hue;
    }

    public String getSat() {
        return sat;
    }

    public void setSat(String sat) {
        this.sat = sat;
    }

    public String getXy() {
        return xy;
    }

    public void setXy(String xy) {
        this.xy = xy;
    }

    public String getCt() {
        return ct;
    }

    public void setCt(String ct) {
        this.ct = ct;
    }

    public String getAlert() {
        return alert;
    }

    public void setAlert(String alert) {
        this.alert = alert;
    }

    public String getEffect() {
        return effect;
    }

    public void setEffect(String effect) {
        this.effect = effect;
    }

    public String getColormode() {
        return colormode;
    }

    public void setColormode(String colormode) {
        this.colormode = colormode;
    }

    public String getReachable() {
        return reachable;
    }

    public void setReachable(String reachable) {
        this.reachable = reachable;
    }


    public String toString()

    {

        String s = "id="+getId()+"&type="+getType()+"&name="+getName()+
                "&modelid="+getModelid()+"&swversion="+getSwversion()+
                "&on="+getOn()+"&bri="+getBri()+"&hue="+getHue()+"&sat="+
                getSat()+ "&xy="+getXy()+"&ct="+getCt()+"&alert="+getAlert()+
                "&effect="+getEffect()+"&colormode="+getColormode()+"&reachable="+
                getReachable()+"";


        return s;

    }


}
