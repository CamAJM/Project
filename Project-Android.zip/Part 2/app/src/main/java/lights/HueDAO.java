package lights;


import java.util.ArrayList;
import java.sql.*;



public class HueDAO {

    ArrayList<Light> list = new ArrayList<Light>();
    Light oneLight = null;
    Connection conn = null;
    Statement stmt = null;

    public HueDAO() {}


    public void openConnection(){
        // loading jdbc driver for mysql
        try{
            Class.forName("com.mysql.jdbc.Driver").newInstance();
        } catch(Exception e) { System.out.println(e); }

        // connecting to database
        try{
            // connection string for demos database, username demos, password demos
            // connect to cloud server for SQL database here
            conn = DriverManager.getConnection
                    ("jdbc:mysql://mudfoot.doc.stu.mmu.ac.uk:3306/whitej?user=whitej&password=Uclefask3");
            //  ("jdbc:sqlite:films.sqlite");
            stmt = conn.createStatement();
        } catch(SQLException se) { System.out.println(se); }
    }
    private void closeConnection(){
        try {
            conn.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    private Light getNextLight(ResultSet rs){
        Light thisLight=null;
        try {
            thisLight = new Light(
                    rs.getString("id"),
                    rs.getString("type"),
                    rs.getString("name"),
                    rs.getString("modelid"),
                    rs.getString("swversion"),
                    rs.getString("on"),
                    rs.getString("bri"),
                    rs.getString("hue"),
                    rs.getString("sat"),
                    rs.getString("xy"),
                    rs.getString("ct"),
                    rs.getString("alert"),
                    rs.getString("effect"),
                    rs.getString("colormode"),
                    rs.getString("reachable"),
                    rs.getString("groupID"),
                    rs.getString("houseID"));
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return thisLight;
    }

    public ArrayList<Light> findAllByGroup(String id)
    {
        openConnection();


        try{
            String selectSQL = "SELECT * FROM Light WHERE groupID ="+id+";";
            ResultSet rs1 = stmt.executeQuery(selectSQL);
            // Retrieve the results

            while(rs1.next()){
                oneLight = getNextLight(rs1);
                list.add(oneLight);
            }


            stmt.close();
        } catch(SQLException se) { System.out.println(se); }


        return list;


    }



	/*
   public ArrayList<Light> getAllFilms(){

		ArrayList<Light> allFilms = new ArrayList<Light>();
		openConnection();

	    // Create select statement and execute it
		try{
		    String selectSQL = "select * from films";
		    ResultSet rs1 = stmt.executeQuery(selectSQL);
		    System.out.print(rs1);
	    // Retrieve the results
		    while(rs1.next()){
		    	oneLight = getNextFilm(rs1);
		    	allFilms.add(oneLight);
		   }

		    stmt.close();
		    closeConnection();
		} catch(SQLException se) { System.out.println(se); }

	   return allFilms;
   }

   public Light getFilmByID(int id){

		openConnection();
		oneLight=null;
	    // Create select statement and execute it
		try{
		    String selectSQL = "select * from films where id="+id;
		    ResultSet rs1 = stmt.executeQuery(selectSQL);
	    // Retrieve the results
		    while(rs1.next()){
		    	oneLight = getNextFilm(rs1);
		    }

		    stmt.close();
		    closeConnection();
		} catch(SQLException se) { System.out.println(se); }

	   return oneLight;
   }



   public ArrayList<Light> getFilmByName(String query){

		ArrayList<Light> filmNames = new ArrayList<Light>();
		openConnection();

	    // Create select statement and execute it
		try{
		    String selectSQL = "select * from films where title like '%"+query+"%';";
		    ResultSet rs1 = stmt.executeQuery(selectSQL);
		    System.out.print(rs1);
	    // Retrieve the results
		    while(rs1.next()){
		    	oneLight = getNextFilm(rs1);
		    	filmNames.add(oneLight);
		   }

		    stmt.close();
		    closeConnection();
		} catch(SQLException se) { System.out.println(se); }

	   return filmNames;
  }



   */

    public Light insertLight(Light insert) {

        System.out.println(insert);

        openConnection();
        oneLight= null;


        try {
            String selectSQL = "insert into Light VALUES("+insert+");";
            stmt.executeUpdate(selectSQL);
            //TODO need to set up a second sql statment

            System.out.println("Added to the database");

            stmt.close();
            closeConnection();
        } catch(SQLException se) { System.out.println(se); }


        return oneLight;
    }




}
